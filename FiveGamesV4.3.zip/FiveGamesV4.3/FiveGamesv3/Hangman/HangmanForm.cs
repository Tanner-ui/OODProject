﻿using System;
using System.Drawing;
using System.Windows.Forms;
using FiveGames;

namespace HangmanForm
{
    public partial class HangmanForm : GameBase
    {
        #region Creation/Loading
        private HangmanData hangmanGame = new HangmanData();
        private int gamesWon = 0;
        private int gamesLost = 0;

        public HangmanForm()
        {
            InitializeComponent();
            SetScoreLabel(scoreLabel);
            StartNewGame();
        }

        private void StartNewGame()
        {
            hangmanGame.StartNewGame();
            UpdateHangmanImage(0);
            UpdateDisplay();
            UpdateGuessedLetters();
        }
        #endregion

        #region Clicks
        private void btnGuess_Click(object sender, EventArgs e)
        {
            if (txtInput.Text.Length == 1)
            {
                char guess = txtInput.Text.ToLower()[0];
                txtInput.Clear();

                if (!hangmanGame.GuessedLetters.Contains(guess))
                {
                    bool correct = hangmanGame.ProcessGuess(guess);
                    if (!correct)
                        UpdateHangmanImage(hangmanGame.IncorrectGuesses);

                    UpdateDisplay();
                    UpdateGuessedLetters();
                    CheckGameStatus();
                }
            }
        }

        private void btnRestart_Click(object sender, EventArgs e)
        {
            StartNewGame();
        }
        #endregion

        #region Update
        private void UpdateDisplay()
        {
            lblWordDisplay.Text = "Word: " + hangmanGame.DisplayWord;
            lblIncorrectGuesses.Text = $"Incorrect Guesses: {hangmanGame.IncorrectGuesses}/{hangmanGame.MaxIncorrectGuesses}";
        }

        private void UpdateHangmanImage(int stage)
        {
            string imagePath = $"hangman{stage}.png";
            if (System.IO.File.Exists(imagePath))
                hangmanImage.Image = Image.FromFile(imagePath);
        }

        private void UpdateGuessedLetters()
        {
            lblGuessedLetters.Text = "Guessed Letters: " + string.Join(", ", hangmanGame.GuessedLetters);
        }

        private void CheckGameStatus()
        {
            if (hangmanGame.IsGameWon)
            {
                gamesWon++;
                UpdateScoreDisplay();
                MessageBox.Show("You Win!", "Hangman", MessageBoxButtons.OK, MessageBoxIcon.Information);
                StartNewGame();
            }
            else if (hangmanGame.IsGameOver)
            {
                gamesLost++;
                UpdateScoreDisplay();
                MessageBox.Show($"Game Over! The word was {hangmanGame.SelectedWord}", "Hangman", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                StartNewGame();
            }
        }

        protected override string GetFormattedScore()
        {
            return $"Wins: {gamesWon} | Losses: {gamesLost}";
        }
        #endregion
    }
}