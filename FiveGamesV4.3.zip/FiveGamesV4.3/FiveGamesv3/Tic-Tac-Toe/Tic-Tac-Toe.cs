﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.Drawing.Text;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;



namespace FiveGames
{
    public partial class Tic_Tac_Toe : GameBase
    {
        public int random2;
        TicData ticgame = new TicData();

        private int xWins = 0;
        private int oWins = 0;

        public Tic_Tac_Toe()
        {
            InitializeComponent();
            SetScoreLabel(scoreLabel);
        }

        private void tl_Click(object sender, EventArgs e)
        {
            ticgame.X(1);
            text(1);
            TicData.turn++;
            ticgame.O();
            random2 = ticgame.random1;
            text(random2);

            check();
        }

        private void tm_Click(object sender, EventArgs e)
        {
            ticgame.X(2);
            text(2);
            TicData.turn++;
            check();

            ticgame.O();
            random2 = ticgame.random1;
            text(random2);
            check();
        }

        private void tr_Click(object sender, EventArgs e)
        {
            ticgame.X(3);
            text(3);
            TicData.turn++;
            check();

            ticgame.O();
            random2 = ticgame.random1;
            text(random2);
            check();
        }

        private void ml_Click(object sender, EventArgs e)
        {
            ticgame.X(4);
            text(4);
            TicData.turn++;
            check();

            ticgame.O();
            random2 = ticgame.random1;
            text(random2);
            check();
        }

        private void mm_Click(object sender, EventArgs e)
        {
            ticgame.X(5);
            text(5);
            TicData.turn++;
            check();

            ticgame.O();
            random2 = ticgame.random1;
            text(random2);
            check();
        }

        private void mr_Click(object sender, EventArgs e)
        {
            ticgame.X(6);
            text(6);
            TicData.turn++;
            check();

            ticgame.O();
            random2 = ticgame.random1;
            text(random2);
            check();
        }

        private void bl_Click(object sender, EventArgs e)
        {
            ticgame.X(7);
            text(7);
            TicData.turn++;
            check();

            ticgame.O();
            random2 = ticgame.random1;
            text(random2);
            check();
        }

        private void bm_Click(object sender, EventArgs e)
        {
            ticgame.X(8);
            text(8);
            TicData.turn++;
            check();

            ticgame.O();
            random2 = ticgame.random1;
            text(random2);
            check();
        }

        private void br_Click(object sender, EventArgs e)
        {
            ticgame.X(9);
            text(9);
            TicData.turn++;
            check();

            ticgame.O();
            random2 = ticgame.random1;
            text(random2);
            check();
        }

        private void restart_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < 9; i++)
                TicData.arr[i] = 0;
            TicData.gameover = false;
            tl.Text = " ";
            tm.Text = " ";
            tr.Text = " ";
            ml.Text = " ";
            mm.Text = " ";
            mr.Text = " ";
            bl.Text = " ";
            bm.Text = " ";
            br.Text = " ";
            end.Text = " ";
            TicData.turnNum = 0;
            TicData.turn = 1;
        }

        public void check()
        {
            if (TicData.arr[0] == TicData.arr[1] && TicData.arr[1] == TicData.arr[2] && TicData.arr[0] != 0)
            {
                TicData.gameover = true;
                if (TicData.arr[0] == 1)
                {
                    end.Text = "You win!";
                    xWins++;  // Increment X Wins
                }
                else
                {
                    end.Text = "You Lose!";
                    oWins++;  // Increment O Wins
                }
                UpdateScoreDisplay();
            }
            else if (TicData.arr[3] == TicData.arr[4] && TicData.arr[4] == TicData.arr[5] && TicData.arr[3] != 0)
            {
                TicData.gameover = true;
                if (TicData.arr[3] == 1)
                {
                    end.Text = "You win!";
                    xWins++;
                }
                else
                {
                    end.Text = "You Lose!";
                    oWins++;
                }
                UpdateScoreDisplay();
            }
            else if (TicData.arr[6] == TicData.arr[7] && TicData.arr[7] == TicData.arr[8] && TicData.arr[6] != 0)
            {
                TicData.gameover = true;
                if (TicData.arr[6] == 1)
                {
                    end.Text = "You win!";
                    xWins++;
                }
                else
                {
                    end.Text = "You Lose!";
                    oWins++;
                }
                UpdateScoreDisplay();
            }
            else if (TicData.arr[0] == TicData.arr[3] && TicData.arr[3] == TicData.arr[6] && TicData.arr[0] != 0)
            {
                TicData.gameover = true;
                if (TicData.arr[0] == 1)
                {
                    end.Text = "You win!";
                    xWins++;
                }
                else
                {
                    end.Text = "You Lose!";
                    oWins++;
                }
                UpdateScoreDisplay();
            }
            else if (TicData.arr[1] == TicData.arr[4] && TicData.arr[4] == TicData.arr[7] && TicData.arr[1] != 0)
            {
                TicData.gameover = true;
                if (TicData.arr[1] == 1)
                {
                    end.Text = "You win!";
                    xWins++;
                }
                else
                {
                    end.Text = "You Lose!";
                    oWins++;
                }
                UpdateScoreDisplay();
            }
            else if (TicData.arr[2] == TicData.arr[5] && TicData.arr[5] == TicData.arr[8] && TicData.arr[2] != 0)
            {
                TicData.gameover = true;
                if (TicData.arr[2] == 1)
                {
                    end.Text = "You win!";
                    xWins++;
                }
                else
                {
                    end.Text = "You Lose!";
                    oWins++;
                }
                UpdateScoreDisplay();
            }
            else if (TicData.arr[0] == TicData.arr[4] && TicData.arr[4] == TicData.arr[8] && TicData.arr[0] != 0)
            {
                TicData.gameover = true;
                if (TicData.arr[0] == 1)
                {
                    end.Text = "You win!";
                    xWins++;
                }
                else
                {
                    end.Text = "You Lose!";
                    oWins++;
                }
                UpdateScoreDisplay();
            }
            else if (TicData.arr[2] == TicData.arr[4] && TicData.arr[4] == TicData.arr[6] && TicData.arr[2] != 0)
            {
                TicData.gameover = true;
                if (TicData.arr[2] == 1)
                {
                    end.Text = "You win!";
                    xWins++;
                }
                else
                {
                    end.Text = "You Lose!";
                    oWins++;
                }
                UpdateScoreDisplay();
            }
        }


        public void text(int x)
        {
            if (TicData.gameover == false)
            {
                if (x == 1 && TicData.turn == 1)
                    tl.Text = "X";
                if (x == 2 && TicData.turn == 1)
                    tm.Text = "X";
                if (x == 3 && TicData.turn == 1)
                    tr.Text = "X";
                if (x == 4 && TicData.turn == 1)
                    ml.Text = "X";
                if (x == 5 && TicData.turn == 1)
                    mm.Text = "X";
                if (x == 6 && TicData.turn == 1)
                    mr.Text = "X";
                if (x == 7 && TicData.turn == 1)
                    bl.Text = "X";
                if (x == 8 && TicData.turn == 1)
                    bm.Text = "X";
                if (x == 9 && TicData.turn == 1)
                    br.Text = "X";


                if (x == 1 && TicData.turn == 2)
                {
                    tl.Text = "O";
                    TicData.turn--;
                }
                if (x == 2 && TicData.turn == 2)
                {
                    tm.Text = "O";
                    TicData.turn--;
                }
                if (x == 3 && TicData.turn == 2)
                {
                    tr.Text = "O";
                    TicData.turn--;
                }
                if (x == 4 && TicData.turn == 2)
                {
                    ml.Text = "O";
                    TicData.turn--;
                }
                if (x == 5 && TicData.turn == 2)
                {
                    mm.Text = "O";
                    TicData.turn--;
                }
                if (x == 6 && TicData.turn == 2)
                {
                    mr.Text = "O";
                    TicData.turn--;
                }
                if (x == 7 && TicData.turn == 2)
                {
                    bl.Text = "O";
                    TicData.turn--;
                }
                if (x == 8 && TicData.turn == 2)
                {
                    bm.Text = "O";
                    TicData.turn--;
                }
                if (x == 9 && TicData.turn == 2)
                {
                    br.Text = "O";
                    TicData.turn--;
                }
            }
        }

        protected override string GetFormattedScore()
        {
            return $"X Wins: {xWins} | O Wins: {oWins}";
        }

    }
}
