﻿namespace FiveGames
{
    partial class SudokuForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.zero0 = new System.Windows.Forms.TextBox();
            this.zero1 = new System.Windows.Forms.TextBox();
            this.zero3 = new System.Windows.Forms.TextBox();
            this.zero2 = new System.Windows.Forms.TextBox();
            this.zero5 = new System.Windows.Forms.TextBox();
            this.zero4 = new System.Windows.Forms.TextBox();
            this.zero7 = new System.Windows.Forms.TextBox();
            this.zero6 = new System.Windows.Forms.TextBox();
            this.zero8 = new System.Windows.Forms.TextBox();
            this.one8 = new System.Windows.Forms.TextBox();
            this.one7 = new System.Windows.Forms.TextBox();
            this.one6 = new System.Windows.Forms.TextBox();
            this.one5 = new System.Windows.Forms.TextBox();
            this.one4 = new System.Windows.Forms.TextBox();
            this.one3 = new System.Windows.Forms.TextBox();
            this.one2 = new System.Windows.Forms.TextBox();
            this.one1 = new System.Windows.Forms.TextBox();
            this.one0 = new System.Windows.Forms.TextBox();
            this.two8 = new System.Windows.Forms.TextBox();
            this.two7 = new System.Windows.Forms.TextBox();
            this.two6 = new System.Windows.Forms.TextBox();
            this.two5 = new System.Windows.Forms.TextBox();
            this.two4 = new System.Windows.Forms.TextBox();
            this.two3 = new System.Windows.Forms.TextBox();
            this.two2 = new System.Windows.Forms.TextBox();
            this.two1 = new System.Windows.Forms.TextBox();
            this.two0 = new System.Windows.Forms.TextBox();
            this.three8 = new System.Windows.Forms.TextBox();
            this.three7 = new System.Windows.Forms.TextBox();
            this.three6 = new System.Windows.Forms.TextBox();
            this.three5 = new System.Windows.Forms.TextBox();
            this.three4 = new System.Windows.Forms.TextBox();
            this.three3 = new System.Windows.Forms.TextBox();
            this.three2 = new System.Windows.Forms.TextBox();
            this.three1 = new System.Windows.Forms.TextBox();
            this.three0 = new System.Windows.Forms.TextBox();
            this.four8 = new System.Windows.Forms.TextBox();
            this.four7 = new System.Windows.Forms.TextBox();
            this.four6 = new System.Windows.Forms.TextBox();
            this.four5 = new System.Windows.Forms.TextBox();
            this.four4 = new System.Windows.Forms.TextBox();
            this.four3 = new System.Windows.Forms.TextBox();
            this.four2 = new System.Windows.Forms.TextBox();
            this.four1 = new System.Windows.Forms.TextBox();
            this.four0 = new System.Windows.Forms.TextBox();
            this.five8 = new System.Windows.Forms.TextBox();
            this.five7 = new System.Windows.Forms.TextBox();
            this.five6 = new System.Windows.Forms.TextBox();
            this.five5 = new System.Windows.Forms.TextBox();
            this.five4 = new System.Windows.Forms.TextBox();
            this.five3 = new System.Windows.Forms.TextBox();
            this.five2 = new System.Windows.Forms.TextBox();
            this.five1 = new System.Windows.Forms.TextBox();
            this.five0 = new System.Windows.Forms.TextBox();
            this.six8 = new System.Windows.Forms.TextBox();
            this.six7 = new System.Windows.Forms.TextBox();
            this.six6 = new System.Windows.Forms.TextBox();
            this.six5 = new System.Windows.Forms.TextBox();
            this.six4 = new System.Windows.Forms.TextBox();
            this.six3 = new System.Windows.Forms.TextBox();
            this.six2 = new System.Windows.Forms.TextBox();
            this.six1 = new System.Windows.Forms.TextBox();
            this.six0 = new System.Windows.Forms.TextBox();
            this.seven8 = new System.Windows.Forms.TextBox();
            this.seven7 = new System.Windows.Forms.TextBox();
            this.seven6 = new System.Windows.Forms.TextBox();
            this.seven5 = new System.Windows.Forms.TextBox();
            this.seven4 = new System.Windows.Forms.TextBox();
            this.seven3 = new System.Windows.Forms.TextBox();
            this.seven2 = new System.Windows.Forms.TextBox();
            this.seven1 = new System.Windows.Forms.TextBox();
            this.seven0 = new System.Windows.Forms.TextBox();
            this.eight8 = new System.Windows.Forms.TextBox();
            this.eight7 = new System.Windows.Forms.TextBox();
            this.eight6 = new System.Windows.Forms.TextBox();
            this.eight5 = new System.Windows.Forms.TextBox();
            this.eight4 = new System.Windows.Forms.TextBox();
            this.eight3 = new System.Windows.Forms.TextBox();
            this.eight2 = new System.Windows.Forms.TextBox();
            this.eight1 = new System.Windows.Forms.TextBox();
            this.eight0 = new System.Windows.Forms.TextBox();
            this.textBox82 = new System.Windows.Forms.TextBox();
            this.textBox83 = new System.Windows.Forms.TextBox();
            this.textBox84 = new System.Windows.Forms.TextBox();
            this.textBox85 = new System.Windows.Forms.TextBox();
            this.textBox86 = new System.Windows.Forms.TextBox();
            this.textBox87 = new System.Windows.Forms.TextBox();
            this.textBox88 = new System.Windows.Forms.TextBox();
            this.textBox89 = new System.Windows.Forms.TextBox();
            this.textBox90 = new System.Windows.Forms.TextBox();
            this.textBox91 = new System.Windows.Forms.TextBox();
            this.textBox92 = new System.Windows.Forms.TextBox();
            this.textBox93 = new System.Windows.Forms.TextBox();
            this.textBox94 = new System.Windows.Forms.TextBox();
            this.textBox95 = new System.Windows.Forms.TextBox();
            this.textBox96 = new System.Windows.Forms.TextBox();
            this.textBox97 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.Sudoku1 = new System.Windows.Forms.Label();
            this.Reset_Button = new System.Windows.Forms.Button();
            this.Check_Button = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // zero0
            // 
            this.zero0.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.zero0.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.zero0.Font = new System.Drawing.Font("Stencil", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.zero0.ForeColor = System.Drawing.SystemColors.WindowText;
            this.zero0.Location = new System.Drawing.Point(48, 157);
            this.zero0.Multiline = true;
            this.zero0.Name = "zero0";
            this.zero0.Size = new System.Drawing.Size(50, 49);
            this.zero0.TabIndex = 0;
            this.zero0.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // zero1
            // 
            this.zero1.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.zero1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.zero1.Font = new System.Drawing.Font("Stencil", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.zero1.Location = new System.Drawing.Point(113, 157);
            this.zero1.Multiline = true;
            this.zero1.Name = "zero1";
            this.zero1.Size = new System.Drawing.Size(50, 49);
            this.zero1.TabIndex = 1;
            this.zero1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // zero3
            // 
            this.zero3.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.zero3.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.zero3.Font = new System.Drawing.Font("Stencil", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.zero3.Location = new System.Drawing.Point(243, 157);
            this.zero3.Multiline = true;
            this.zero3.Name = "zero3";
            this.zero3.Size = new System.Drawing.Size(50, 49);
            this.zero3.TabIndex = 3;
            this.zero3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // zero2
            // 
            this.zero2.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.zero2.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.zero2.Font = new System.Drawing.Font("Stencil", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.zero2.Location = new System.Drawing.Point(178, 157);
            this.zero2.Multiline = true;
            this.zero2.Name = "zero2";
            this.zero2.Size = new System.Drawing.Size(50, 49);
            this.zero2.TabIndex = 2;
            this.zero2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // zero5
            // 
            this.zero5.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.zero5.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.zero5.Font = new System.Drawing.Font("Stencil", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.zero5.Location = new System.Drawing.Point(374, 157);
            this.zero5.Multiline = true;
            this.zero5.Name = "zero5";
            this.zero5.Size = new System.Drawing.Size(50, 49);
            this.zero5.TabIndex = 5;
            this.zero5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // zero4
            // 
            this.zero4.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.zero4.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.zero4.Font = new System.Drawing.Font("Stencil", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.zero4.Location = new System.Drawing.Point(309, 157);
            this.zero4.Multiline = true;
            this.zero4.Name = "zero4";
            this.zero4.Size = new System.Drawing.Size(50, 49);
            this.zero4.TabIndex = 4;
            this.zero4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // zero7
            // 
            this.zero7.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.zero7.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.zero7.Font = new System.Drawing.Font("Stencil", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.zero7.Location = new System.Drawing.Point(506, 157);
            this.zero7.Multiline = true;
            this.zero7.Name = "zero7";
            this.zero7.Size = new System.Drawing.Size(50, 49);
            this.zero7.TabIndex = 7;
            this.zero7.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // zero6
            // 
            this.zero6.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.zero6.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.zero6.Font = new System.Drawing.Font("Stencil", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.zero6.Location = new System.Drawing.Point(441, 157);
            this.zero6.Multiline = true;
            this.zero6.Name = "zero6";
            this.zero6.Size = new System.Drawing.Size(50, 49);
            this.zero6.TabIndex = 6;
            this.zero6.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // zero8
            // 
            this.zero8.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.zero8.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.zero8.Font = new System.Drawing.Font("Stencil", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.zero8.Location = new System.Drawing.Point(572, 157);
            this.zero8.Multiline = true;
            this.zero8.Name = "zero8";
            this.zero8.Size = new System.Drawing.Size(50, 49);
            this.zero8.TabIndex = 8;
            this.zero8.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // one8
            // 
            this.one8.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.one8.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.one8.Font = new System.Drawing.Font("Stencil", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.one8.Location = new System.Drawing.Point(572, 227);
            this.one8.Multiline = true;
            this.one8.Name = "one8";
            this.one8.Size = new System.Drawing.Size(50, 49);
            this.one8.TabIndex = 17;
            this.one8.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // one7
            // 
            this.one7.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.one7.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.one7.Font = new System.Drawing.Font("Stencil", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.one7.Location = new System.Drawing.Point(506, 227);
            this.one7.Multiline = true;
            this.one7.Name = "one7";
            this.one7.Size = new System.Drawing.Size(50, 49);
            this.one7.TabIndex = 16;
            this.one7.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // one6
            // 
            this.one6.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.one6.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.one6.Font = new System.Drawing.Font("Stencil", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.one6.Location = new System.Drawing.Point(441, 227);
            this.one6.Multiline = true;
            this.one6.Name = "one6";
            this.one6.Size = new System.Drawing.Size(50, 49);
            this.one6.TabIndex = 15;
            this.one6.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // one5
            // 
            this.one5.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.one5.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.one5.Font = new System.Drawing.Font("Stencil", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.one5.Location = new System.Drawing.Point(374, 227);
            this.one5.Multiline = true;
            this.one5.Name = "one5";
            this.one5.Size = new System.Drawing.Size(50, 49);
            this.one5.TabIndex = 14;
            this.one5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // one4
            // 
            this.one4.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.one4.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.one4.Font = new System.Drawing.Font("Stencil", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.one4.Location = new System.Drawing.Point(309, 227);
            this.one4.Multiline = true;
            this.one4.Name = "one4";
            this.one4.Size = new System.Drawing.Size(50, 49);
            this.one4.TabIndex = 13;
            this.one4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // one3
            // 
            this.one3.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.one3.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.one3.Font = new System.Drawing.Font("Stencil", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.one3.Location = new System.Drawing.Point(243, 227);
            this.one3.Multiline = true;
            this.one3.Name = "one3";
            this.one3.Size = new System.Drawing.Size(50, 49);
            this.one3.TabIndex = 12;
            this.one3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // one2
            // 
            this.one2.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.one2.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.one2.Font = new System.Drawing.Font("Stencil", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.one2.Location = new System.Drawing.Point(178, 227);
            this.one2.Multiline = true;
            this.one2.Name = "one2";
            this.one2.Size = new System.Drawing.Size(50, 49);
            this.one2.TabIndex = 11;
            this.one2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // one1
            // 
            this.one1.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.one1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.one1.Font = new System.Drawing.Font("Stencil", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.one1.Location = new System.Drawing.Point(113, 227);
            this.one1.Multiline = true;
            this.one1.Name = "one1";
            this.one1.Size = new System.Drawing.Size(50, 49);
            this.one1.TabIndex = 10;
            this.one1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // one0
            // 
            this.one0.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.one0.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.one0.Font = new System.Drawing.Font("Stencil", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.one0.Location = new System.Drawing.Point(48, 227);
            this.one0.Multiline = true;
            this.one0.Name = "one0";
            this.one0.Size = new System.Drawing.Size(50, 49);
            this.one0.TabIndex = 9;
            this.one0.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // two8
            // 
            this.two8.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.two8.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.two8.Font = new System.Drawing.Font("Stencil", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.two8.Location = new System.Drawing.Point(572, 299);
            this.two8.Multiline = true;
            this.two8.Name = "two8";
            this.two8.Size = new System.Drawing.Size(50, 49);
            this.two8.TabIndex = 26;
            this.two8.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // two7
            // 
            this.two7.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.two7.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.two7.Font = new System.Drawing.Font("Stencil", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.two7.Location = new System.Drawing.Point(506, 299);
            this.two7.Multiline = true;
            this.two7.Name = "two7";
            this.two7.Size = new System.Drawing.Size(50, 49);
            this.two7.TabIndex = 25;
            this.two7.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // two6
            // 
            this.two6.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.two6.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.two6.Font = new System.Drawing.Font("Stencil", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.two6.Location = new System.Drawing.Point(441, 299);
            this.two6.Multiline = true;
            this.two6.Name = "two6";
            this.two6.Size = new System.Drawing.Size(50, 49);
            this.two6.TabIndex = 24;
            this.two6.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // two5
            // 
            this.two5.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.two5.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.two5.Font = new System.Drawing.Font("Stencil", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.two5.Location = new System.Drawing.Point(374, 299);
            this.two5.Multiline = true;
            this.two5.Name = "two5";
            this.two5.Size = new System.Drawing.Size(50, 49);
            this.two5.TabIndex = 23;
            this.two5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // two4
            // 
            this.two4.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.two4.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.two4.Font = new System.Drawing.Font("Stencil", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.two4.Location = new System.Drawing.Point(309, 299);
            this.two4.Multiline = true;
            this.two4.Name = "two4";
            this.two4.Size = new System.Drawing.Size(50, 49);
            this.two4.TabIndex = 22;
            this.two4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // two3
            // 
            this.two3.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.two3.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.two3.Font = new System.Drawing.Font("Stencil", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.two3.Location = new System.Drawing.Point(243, 299);
            this.two3.Multiline = true;
            this.two3.Name = "two3";
            this.two3.Size = new System.Drawing.Size(50, 49);
            this.two3.TabIndex = 21;
            this.two3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // two2
            // 
            this.two2.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.two2.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.two2.Font = new System.Drawing.Font("Stencil", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.two2.Location = new System.Drawing.Point(178, 299);
            this.two2.Multiline = true;
            this.two2.Name = "two2";
            this.two2.Size = new System.Drawing.Size(50, 49);
            this.two2.TabIndex = 20;
            this.two2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // two1
            // 
            this.two1.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.two1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.two1.Font = new System.Drawing.Font("Stencil", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.two1.Location = new System.Drawing.Point(113, 299);
            this.two1.Multiline = true;
            this.two1.Name = "two1";
            this.two1.Size = new System.Drawing.Size(50, 49);
            this.two1.TabIndex = 19;
            this.two1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // two0
            // 
            this.two0.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.two0.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.two0.Font = new System.Drawing.Font("Stencil", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.two0.Location = new System.Drawing.Point(48, 299);
            this.two0.Multiline = true;
            this.two0.Name = "two0";
            this.two0.Size = new System.Drawing.Size(50, 49);
            this.two0.TabIndex = 18;
            this.two0.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // three8
            // 
            this.three8.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.three8.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.three8.Font = new System.Drawing.Font("Stencil", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.three8.Location = new System.Drawing.Point(572, 370);
            this.three8.Multiline = true;
            this.three8.Name = "three8";
            this.three8.Size = new System.Drawing.Size(50, 49);
            this.three8.TabIndex = 35;
            this.three8.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // three7
            // 
            this.three7.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.three7.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.three7.Font = new System.Drawing.Font("Stencil", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.three7.Location = new System.Drawing.Point(506, 370);
            this.three7.Multiline = true;
            this.three7.Name = "three7";
            this.three7.Size = new System.Drawing.Size(50, 49);
            this.three7.TabIndex = 34;
            this.three7.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // three6
            // 
            this.three6.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.three6.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.three6.Font = new System.Drawing.Font("Stencil", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.three6.Location = new System.Drawing.Point(441, 370);
            this.three6.Multiline = true;
            this.three6.Name = "three6";
            this.three6.Size = new System.Drawing.Size(50, 49);
            this.three6.TabIndex = 33;
            this.three6.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // three5
            // 
            this.three5.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.three5.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.three5.Font = new System.Drawing.Font("Stencil", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.three5.Location = new System.Drawing.Point(374, 370);
            this.three5.Multiline = true;
            this.three5.Name = "three5";
            this.three5.Size = new System.Drawing.Size(50, 49);
            this.three5.TabIndex = 32;
            this.three5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // three4
            // 
            this.three4.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.three4.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.three4.Font = new System.Drawing.Font("Stencil", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.three4.Location = new System.Drawing.Point(309, 370);
            this.three4.Multiline = true;
            this.three4.Name = "three4";
            this.three4.Size = new System.Drawing.Size(50, 49);
            this.three4.TabIndex = 31;
            this.three4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // three3
            // 
            this.three3.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.three3.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.three3.Font = new System.Drawing.Font("Stencil", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.three3.Location = new System.Drawing.Point(243, 370);
            this.three3.Multiline = true;
            this.three3.Name = "three3";
            this.three3.Size = new System.Drawing.Size(50, 49);
            this.three3.TabIndex = 30;
            this.three3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // three2
            // 
            this.three2.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.three2.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.three2.Font = new System.Drawing.Font("Stencil", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.three2.Location = new System.Drawing.Point(178, 370);
            this.three2.Multiline = true;
            this.three2.Name = "three2";
            this.three2.Size = new System.Drawing.Size(50, 49);
            this.three2.TabIndex = 29;
            this.three2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // three1
            // 
            this.three1.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.three1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.three1.Font = new System.Drawing.Font("Stencil", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.three1.Location = new System.Drawing.Point(113, 370);
            this.three1.Multiline = true;
            this.three1.Name = "three1";
            this.three1.Size = new System.Drawing.Size(50, 49);
            this.three1.TabIndex = 28;
            this.three1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // three0
            // 
            this.three0.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.three0.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.three0.Font = new System.Drawing.Font("Stencil", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.three0.Location = new System.Drawing.Point(48, 370);
            this.three0.Multiline = true;
            this.three0.Name = "three0";
            this.three0.Size = new System.Drawing.Size(50, 49);
            this.three0.TabIndex = 27;
            this.three0.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // four8
            // 
            this.four8.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.four8.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.four8.Font = new System.Drawing.Font("Stencil", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.four8.Location = new System.Drawing.Point(572, 442);
            this.four8.Multiline = true;
            this.four8.Name = "four8";
            this.four8.Size = new System.Drawing.Size(50, 49);
            this.four8.TabIndex = 44;
            this.four8.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // four7
            // 
            this.four7.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.four7.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.four7.Font = new System.Drawing.Font("Stencil", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.four7.Location = new System.Drawing.Point(506, 442);
            this.four7.Multiline = true;
            this.four7.Name = "four7";
            this.four7.Size = new System.Drawing.Size(50, 49);
            this.four7.TabIndex = 43;
            this.four7.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // four6
            // 
            this.four6.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.four6.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.four6.Font = new System.Drawing.Font("Stencil", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.four6.Location = new System.Drawing.Point(441, 442);
            this.four6.Multiline = true;
            this.four6.Name = "four6";
            this.four6.Size = new System.Drawing.Size(50, 49);
            this.four6.TabIndex = 42;
            this.four6.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // four5
            // 
            this.four5.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.four5.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.four5.Font = new System.Drawing.Font("Stencil", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.four5.Location = new System.Drawing.Point(374, 442);
            this.four5.Multiline = true;
            this.four5.Name = "four5";
            this.four5.Size = new System.Drawing.Size(50, 49);
            this.four5.TabIndex = 41;
            this.four5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // four4
            // 
            this.four4.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.four4.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.four4.Font = new System.Drawing.Font("Stencil", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.four4.Location = new System.Drawing.Point(309, 442);
            this.four4.Multiline = true;
            this.four4.Name = "four4";
            this.four4.Size = new System.Drawing.Size(50, 49);
            this.four4.TabIndex = 40;
            this.four4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // four3
            // 
            this.four3.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.four3.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.four3.Font = new System.Drawing.Font("Stencil", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.four3.Location = new System.Drawing.Point(243, 442);
            this.four3.Multiline = true;
            this.four3.Name = "four3";
            this.four3.Size = new System.Drawing.Size(50, 49);
            this.four3.TabIndex = 39;
            this.four3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // four2
            // 
            this.four2.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.four2.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.four2.Font = new System.Drawing.Font("Stencil", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.four2.Location = new System.Drawing.Point(178, 442);
            this.four2.Multiline = true;
            this.four2.Name = "four2";
            this.four2.Size = new System.Drawing.Size(50, 49);
            this.four2.TabIndex = 38;
            this.four2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // four1
            // 
            this.four1.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.four1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.four1.Font = new System.Drawing.Font("Stencil", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.four1.Location = new System.Drawing.Point(113, 442);
            this.four1.Multiline = true;
            this.four1.Name = "four1";
            this.four1.Size = new System.Drawing.Size(50, 49);
            this.four1.TabIndex = 37;
            this.four1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // four0
            // 
            this.four0.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.four0.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.four0.Font = new System.Drawing.Font("Stencil", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.four0.Location = new System.Drawing.Point(48, 442);
            this.four0.Multiline = true;
            this.four0.Name = "four0";
            this.four0.Size = new System.Drawing.Size(50, 49);
            this.four0.TabIndex = 36;
            this.four0.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // five8
            // 
            this.five8.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.five8.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.five8.Font = new System.Drawing.Font("Stencil", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.five8.Location = new System.Drawing.Point(572, 514);
            this.five8.Multiline = true;
            this.five8.Name = "five8";
            this.five8.Size = new System.Drawing.Size(50, 49);
            this.five8.TabIndex = 53;
            this.five8.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // five7
            // 
            this.five7.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.five7.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.five7.Font = new System.Drawing.Font("Stencil", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.five7.Location = new System.Drawing.Point(506, 514);
            this.five7.Multiline = true;
            this.five7.Name = "five7";
            this.five7.Size = new System.Drawing.Size(50, 49);
            this.five7.TabIndex = 52;
            this.five7.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // five6
            // 
            this.five6.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.five6.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.five6.Font = new System.Drawing.Font("Stencil", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.five6.Location = new System.Drawing.Point(441, 514);
            this.five6.Multiline = true;
            this.five6.Name = "five6";
            this.five6.Size = new System.Drawing.Size(50, 49);
            this.five6.TabIndex = 51;
            this.five6.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // five5
            // 
            this.five5.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.five5.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.five5.Font = new System.Drawing.Font("Stencil", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.five5.Location = new System.Drawing.Point(374, 514);
            this.five5.Multiline = true;
            this.five5.Name = "five5";
            this.five5.Size = new System.Drawing.Size(50, 49);
            this.five5.TabIndex = 50;
            this.five5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // five4
            // 
            this.five4.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.five4.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.five4.Font = new System.Drawing.Font("Stencil", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.five4.Location = new System.Drawing.Point(309, 514);
            this.five4.Multiline = true;
            this.five4.Name = "five4";
            this.five4.Size = new System.Drawing.Size(50, 49);
            this.five4.TabIndex = 49;
            this.five4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // five3
            // 
            this.five3.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.five3.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.five3.Font = new System.Drawing.Font("Stencil", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.five3.Location = new System.Drawing.Point(243, 514);
            this.five3.Multiline = true;
            this.five3.Name = "five3";
            this.five3.Size = new System.Drawing.Size(50, 49);
            this.five3.TabIndex = 48;
            this.five3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // five2
            // 
            this.five2.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.five2.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.five2.Font = new System.Drawing.Font("Stencil", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.five2.Location = new System.Drawing.Point(178, 514);
            this.five2.Multiline = true;
            this.five2.Name = "five2";
            this.five2.Size = new System.Drawing.Size(50, 49);
            this.five2.TabIndex = 47;
            this.five2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // five1
            // 
            this.five1.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.five1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.five1.Font = new System.Drawing.Font("Stencil", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.five1.Location = new System.Drawing.Point(113, 514);
            this.five1.Multiline = true;
            this.five1.Name = "five1";
            this.five1.Size = new System.Drawing.Size(50, 49);
            this.five1.TabIndex = 46;
            this.five1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // five0
            // 
            this.five0.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.five0.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.five0.Font = new System.Drawing.Font("Stencil", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.five0.Location = new System.Drawing.Point(48, 514);
            this.five0.Multiline = true;
            this.five0.Name = "five0";
            this.five0.Size = new System.Drawing.Size(50, 49);
            this.five0.TabIndex = 45;
            this.five0.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // six8
            // 
            this.six8.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.six8.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.six8.Font = new System.Drawing.Font("Stencil", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.six8.Location = new System.Drawing.Point(572, 586);
            this.six8.Multiline = true;
            this.six8.Name = "six8";
            this.six8.Size = new System.Drawing.Size(50, 49);
            this.six8.TabIndex = 62;
            this.six8.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // six7
            // 
            this.six7.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.six7.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.six7.Font = new System.Drawing.Font("Stencil", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.six7.Location = new System.Drawing.Point(506, 586);
            this.six7.Multiline = true;
            this.six7.Name = "six7";
            this.six7.Size = new System.Drawing.Size(50, 49);
            this.six7.TabIndex = 61;
            this.six7.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // six6
            // 
            this.six6.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.six6.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.six6.Font = new System.Drawing.Font("Stencil", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.six6.Location = new System.Drawing.Point(441, 586);
            this.six6.Multiline = true;
            this.six6.Name = "six6";
            this.six6.Size = new System.Drawing.Size(50, 49);
            this.six6.TabIndex = 60;
            this.six6.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // six5
            // 
            this.six5.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.six5.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.six5.Font = new System.Drawing.Font("Stencil", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.six5.Location = new System.Drawing.Point(374, 586);
            this.six5.Multiline = true;
            this.six5.Name = "six5";
            this.six5.Size = new System.Drawing.Size(50, 49);
            this.six5.TabIndex = 59;
            this.six5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // six4
            // 
            this.six4.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.six4.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.six4.Font = new System.Drawing.Font("Stencil", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.six4.Location = new System.Drawing.Point(309, 586);
            this.six4.Multiline = true;
            this.six4.Name = "six4";
            this.six4.Size = new System.Drawing.Size(50, 49);
            this.six4.TabIndex = 58;
            this.six4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // six3
            // 
            this.six3.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.six3.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.six3.Font = new System.Drawing.Font("Stencil", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.six3.Location = new System.Drawing.Point(243, 586);
            this.six3.Multiline = true;
            this.six3.Name = "six3";
            this.six3.Size = new System.Drawing.Size(50, 49);
            this.six3.TabIndex = 57;
            this.six3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // six2
            // 
            this.six2.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.six2.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.six2.Font = new System.Drawing.Font("Stencil", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.six2.Location = new System.Drawing.Point(178, 586);
            this.six2.Multiline = true;
            this.six2.Name = "six2";
            this.six2.Size = new System.Drawing.Size(50, 49);
            this.six2.TabIndex = 56;
            this.six2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // six1
            // 
            this.six1.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.six1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.six1.Font = new System.Drawing.Font("Stencil", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.six1.Location = new System.Drawing.Point(113, 586);
            this.six1.Multiline = true;
            this.six1.Name = "six1";
            this.six1.Size = new System.Drawing.Size(50, 49);
            this.six1.TabIndex = 55;
            this.six1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // six0
            // 
            this.six0.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.six0.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.six0.Font = new System.Drawing.Font("Stencil", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.six0.Location = new System.Drawing.Point(48, 586);
            this.six0.Multiline = true;
            this.six0.Name = "six0";
            this.six0.Size = new System.Drawing.Size(50, 49);
            this.six0.TabIndex = 54;
            this.six0.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // seven8
            // 
            this.seven8.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.seven8.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.seven8.Font = new System.Drawing.Font("Stencil", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.seven8.Location = new System.Drawing.Point(572, 656);
            this.seven8.Multiline = true;
            this.seven8.Name = "seven8";
            this.seven8.Size = new System.Drawing.Size(50, 49);
            this.seven8.TabIndex = 71;
            this.seven8.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // seven7
            // 
            this.seven7.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.seven7.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.seven7.Font = new System.Drawing.Font("Stencil", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.seven7.Location = new System.Drawing.Point(506, 656);
            this.seven7.Multiline = true;
            this.seven7.Name = "seven7";
            this.seven7.Size = new System.Drawing.Size(50, 49);
            this.seven7.TabIndex = 70;
            this.seven7.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // seven6
            // 
            this.seven6.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.seven6.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.seven6.Font = new System.Drawing.Font("Stencil", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.seven6.Location = new System.Drawing.Point(441, 656);
            this.seven6.Multiline = true;
            this.seven6.Name = "seven6";
            this.seven6.Size = new System.Drawing.Size(50, 49);
            this.seven6.TabIndex = 69;
            this.seven6.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // seven5
            // 
            this.seven5.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.seven5.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.seven5.Font = new System.Drawing.Font("Stencil", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.seven5.Location = new System.Drawing.Point(374, 656);
            this.seven5.Multiline = true;
            this.seven5.Name = "seven5";
            this.seven5.Size = new System.Drawing.Size(50, 49);
            this.seven5.TabIndex = 68;
            this.seven5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // seven4
            // 
            this.seven4.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.seven4.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.seven4.Font = new System.Drawing.Font("Stencil", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.seven4.Location = new System.Drawing.Point(309, 656);
            this.seven4.Multiline = true;
            this.seven4.Name = "seven4";
            this.seven4.Size = new System.Drawing.Size(50, 49);
            this.seven4.TabIndex = 67;
            this.seven4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // seven3
            // 
            this.seven3.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.seven3.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.seven3.Font = new System.Drawing.Font("Stencil", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.seven3.Location = new System.Drawing.Point(243, 656);
            this.seven3.Multiline = true;
            this.seven3.Name = "seven3";
            this.seven3.Size = new System.Drawing.Size(50, 49);
            this.seven3.TabIndex = 66;
            this.seven3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // seven2
            // 
            this.seven2.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.seven2.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.seven2.Font = new System.Drawing.Font("Stencil", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.seven2.Location = new System.Drawing.Point(178, 656);
            this.seven2.Multiline = true;
            this.seven2.Name = "seven2";
            this.seven2.Size = new System.Drawing.Size(50, 49);
            this.seven2.TabIndex = 65;
            this.seven2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // seven1
            // 
            this.seven1.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.seven1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.seven1.Font = new System.Drawing.Font("Stencil", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.seven1.Location = new System.Drawing.Point(113, 656);
            this.seven1.Multiline = true;
            this.seven1.Name = "seven1";
            this.seven1.Size = new System.Drawing.Size(50, 49);
            this.seven1.TabIndex = 64;
            this.seven1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // seven0
            // 
            this.seven0.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.seven0.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.seven0.Font = new System.Drawing.Font("Stencil", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.seven0.Location = new System.Drawing.Point(48, 656);
            this.seven0.Multiline = true;
            this.seven0.Name = "seven0";
            this.seven0.Size = new System.Drawing.Size(50, 49);
            this.seven0.TabIndex = 63;
            this.seven0.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // eight8
            // 
            this.eight8.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.eight8.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.eight8.Font = new System.Drawing.Font("Stencil", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.eight8.Location = new System.Drawing.Point(572, 727);
            this.eight8.Multiline = true;
            this.eight8.Name = "eight8";
            this.eight8.Size = new System.Drawing.Size(50, 49);
            this.eight8.TabIndex = 80;
            this.eight8.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // eight7
            // 
            this.eight7.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.eight7.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.eight7.Font = new System.Drawing.Font("Stencil", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.eight7.Location = new System.Drawing.Point(506, 727);
            this.eight7.Multiline = true;
            this.eight7.Name = "eight7";
            this.eight7.Size = new System.Drawing.Size(50, 49);
            this.eight7.TabIndex = 79;
            this.eight7.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // eight6
            // 
            this.eight6.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.eight6.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.eight6.Font = new System.Drawing.Font("Stencil", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.eight6.Location = new System.Drawing.Point(441, 727);
            this.eight6.Multiline = true;
            this.eight6.Name = "eight6";
            this.eight6.Size = new System.Drawing.Size(50, 49);
            this.eight6.TabIndex = 78;
            this.eight6.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // eight5
            // 
            this.eight5.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.eight5.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.eight5.Font = new System.Drawing.Font("Stencil", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.eight5.Location = new System.Drawing.Point(374, 727);
            this.eight5.Multiline = true;
            this.eight5.Name = "eight5";
            this.eight5.Size = new System.Drawing.Size(50, 49);
            this.eight5.TabIndex = 77;
            this.eight5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // eight4
            // 
            this.eight4.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.eight4.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.eight4.Font = new System.Drawing.Font("Stencil", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.eight4.Location = new System.Drawing.Point(309, 727);
            this.eight4.Multiline = true;
            this.eight4.Name = "eight4";
            this.eight4.Size = new System.Drawing.Size(50, 49);
            this.eight4.TabIndex = 76;
            this.eight4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // eight3
            // 
            this.eight3.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.eight3.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.eight3.Font = new System.Drawing.Font("Stencil", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.eight3.Location = new System.Drawing.Point(243, 727);
            this.eight3.Multiline = true;
            this.eight3.Name = "eight3";
            this.eight3.Size = new System.Drawing.Size(50, 49);
            this.eight3.TabIndex = 75;
            this.eight3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // eight2
            // 
            this.eight2.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.eight2.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.eight2.Font = new System.Drawing.Font("Stencil", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.eight2.Location = new System.Drawing.Point(178, 727);
            this.eight2.Multiline = true;
            this.eight2.Name = "eight2";
            this.eight2.Size = new System.Drawing.Size(50, 49);
            this.eight2.TabIndex = 74;
            this.eight2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // eight1
            // 
            this.eight1.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.eight1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.eight1.Font = new System.Drawing.Font("Stencil", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.eight1.Location = new System.Drawing.Point(113, 727);
            this.eight1.Multiline = true;
            this.eight1.Name = "eight1";
            this.eight1.Size = new System.Drawing.Size(50, 49);
            this.eight1.TabIndex = 73;
            this.eight1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // eight0
            // 
            this.eight0.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.eight0.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.eight0.Font = new System.Drawing.Font("Stencil", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.eight0.Location = new System.Drawing.Point(48, 727);
            this.eight0.Multiline = true;
            this.eight0.Name = "eight0";
            this.eight0.Size = new System.Drawing.Size(50, 49);
            this.eight0.TabIndex = 72;
            this.eight0.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox82
            // 
            this.textBox82.BackColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.textBox82.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox82.Font = new System.Drawing.Font("Stencil", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox82.Location = new System.Drawing.Point(95, 157);
            this.textBox82.Multiline = true;
            this.textBox82.Name = "textBox82";
            this.textBox82.Size = new System.Drawing.Size(24, 619);
            this.textBox82.TabIndex = 81;
            this.textBox82.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox83
            // 
            this.textBox83.BackColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.textBox83.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox83.Font = new System.Drawing.Font("Stencil", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox83.Location = new System.Drawing.Point(159, 157);
            this.textBox83.Multiline = true;
            this.textBox83.Name = "textBox83";
            this.textBox83.Size = new System.Drawing.Size(24, 619);
            this.textBox83.TabIndex = 82;
            this.textBox83.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox84
            // 
            this.textBox84.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.textBox84.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox84.Font = new System.Drawing.Font("Stencil", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox84.Location = new System.Drawing.Point(225, 157);
            this.textBox84.Multiline = true;
            this.textBox84.Name = "textBox84";
            this.textBox84.Size = new System.Drawing.Size(24, 619);
            this.textBox84.TabIndex = 83;
            this.textBox84.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox85
            // 
            this.textBox85.BackColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.textBox85.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox85.Font = new System.Drawing.Font("Stencil", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox85.Location = new System.Drawing.Point(288, 157);
            this.textBox85.Multiline = true;
            this.textBox85.Name = "textBox85";
            this.textBox85.Size = new System.Drawing.Size(24, 619);
            this.textBox85.TabIndex = 84;
            this.textBox85.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox86
            // 
            this.textBox86.BackColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.textBox86.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox86.Font = new System.Drawing.Font("Stencil", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox86.Location = new System.Drawing.Point(355, 157);
            this.textBox86.Multiline = true;
            this.textBox86.Name = "textBox86";
            this.textBox86.Size = new System.Drawing.Size(24, 619);
            this.textBox86.TabIndex = 85;
            this.textBox86.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox87
            // 
            this.textBox87.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.textBox87.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox87.Font = new System.Drawing.Font("Stencil", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox87.Location = new System.Drawing.Point(420, 157);
            this.textBox87.Multiline = true;
            this.textBox87.Name = "textBox87";
            this.textBox87.Size = new System.Drawing.Size(24, 619);
            this.textBox87.TabIndex = 86;
            this.textBox87.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox88
            // 
            this.textBox88.BackColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.textBox88.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox88.Font = new System.Drawing.Font("Stencil", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox88.Location = new System.Drawing.Point(488, 157);
            this.textBox88.Multiline = true;
            this.textBox88.Name = "textBox88";
            this.textBox88.Size = new System.Drawing.Size(24, 619);
            this.textBox88.TabIndex = 87;
            this.textBox88.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox89
            // 
            this.textBox89.BackColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.textBox89.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox89.Font = new System.Drawing.Font("Stencil", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox89.Location = new System.Drawing.Point(552, 157);
            this.textBox89.Multiline = true;
            this.textBox89.Name = "textBox89";
            this.textBox89.Size = new System.Drawing.Size(24, 619);
            this.textBox89.TabIndex = 88;
            this.textBox89.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox90
            // 
            this.textBox90.BackColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.textBox90.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox90.Font = new System.Drawing.Font("Stencil", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox90.Location = new System.Drawing.Point(48, 198);
            this.textBox90.Multiline = true;
            this.textBox90.Name = "textBox90";
            this.textBox90.Size = new System.Drawing.Size(574, 30);
            this.textBox90.TabIndex = 89;
            this.textBox90.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox91
            // 
            this.textBox91.BackColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.textBox91.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox91.Font = new System.Drawing.Font("Stencil", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox91.Location = new System.Drawing.Point(48, 272);
            this.textBox91.Multiline = true;
            this.textBox91.Name = "textBox91";
            this.textBox91.Size = new System.Drawing.Size(574, 30);
            this.textBox91.TabIndex = 90;
            this.textBox91.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox92
            // 
            this.textBox92.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.textBox92.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox92.Font = new System.Drawing.Font("Stencil", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox92.Location = new System.Drawing.Point(48, 344);
            this.textBox92.Multiline = true;
            this.textBox92.Name = "textBox92";
            this.textBox92.Size = new System.Drawing.Size(574, 30);
            this.textBox92.TabIndex = 91;
            this.textBox92.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox93
            // 
            this.textBox93.BackColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.textBox93.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox93.Font = new System.Drawing.Font("Stencil", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox93.Location = new System.Drawing.Point(48, 415);
            this.textBox93.Multiline = true;
            this.textBox93.Name = "textBox93";
            this.textBox93.Size = new System.Drawing.Size(574, 30);
            this.textBox93.TabIndex = 92;
            this.textBox93.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox94
            // 
            this.textBox94.BackColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.textBox94.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox94.Font = new System.Drawing.Font("Stencil", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox94.Location = new System.Drawing.Point(48, 487);
            this.textBox94.Multiline = true;
            this.textBox94.Name = "textBox94";
            this.textBox94.Size = new System.Drawing.Size(574, 30);
            this.textBox94.TabIndex = 93;
            this.textBox94.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox95
            // 
            this.textBox95.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.textBox95.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox95.Font = new System.Drawing.Font("Stencil", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox95.Location = new System.Drawing.Point(48, 559);
            this.textBox95.Multiline = true;
            this.textBox95.Name = "textBox95";
            this.textBox95.Size = new System.Drawing.Size(574, 30);
            this.textBox95.TabIndex = 94;
            this.textBox95.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox96
            // 
            this.textBox96.BackColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.textBox96.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox96.Font = new System.Drawing.Font("Stencil", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox96.Location = new System.Drawing.Point(48, 630);
            this.textBox96.Multiline = true;
            this.textBox96.Name = "textBox96";
            this.textBox96.Size = new System.Drawing.Size(574, 30);
            this.textBox96.TabIndex = 95;
            this.textBox96.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox97
            // 
            this.textBox97.BackColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.textBox97.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox97.Font = new System.Drawing.Font("Stencil", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox97.Location = new System.Drawing.Point(48, 701);
            this.textBox97.Multiline = true;
            this.textBox97.Name = "textBox97";
            this.textBox97.Size = new System.Drawing.Size(574, 30);
            this.textBox97.TabIndex = 96;
            this.textBox97.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label1
            // 
            this.label1.Location = new System.Drawing.Point(0, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(100, 23);
            this.label1.TabIndex = 0;
            // 
            // Sudoku1
            // 
            this.Sudoku1.AutoSize = true;
            this.Sudoku1.BackColor = System.Drawing.SystemColors.Control;
            this.Sudoku1.Font = new System.Drawing.Font("Microsoft YaHei", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Sudoku1.ForeColor = System.Drawing.SystemColors.WindowText;
            this.Sudoku1.Location = new System.Drawing.Point(44, 23);
            this.Sudoku1.Name = "Sudoku1";
            this.Sudoku1.Size = new System.Drawing.Size(315, 96);
            this.Sudoku1.TabIndex = 97;
            this.Sudoku1.Text = "Sudoku";
            // 
            // Reset_Button
            // 
            this.Reset_Button.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.Reset_Button.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Reset_Button.Font = new System.Drawing.Font("Microsoft YaHei", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Reset_Button.Location = new System.Drawing.Point(460, 91);
            this.Reset_Button.Name = "Reset_Button";
            this.Reset_Button.Size = new System.Drawing.Size(116, 48);
            this.Reset_Button.TabIndex = 98;
            this.Reset_Button.Text = "Reset";
            this.Reset_Button.UseVisualStyleBackColor = false;
            // 
            // Check_Button
            // 
            this.Check_Button.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.Check_Button.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Check_Button.Font = new System.Drawing.Font("Microsoft YaHei", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Check_Button.Location = new System.Drawing.Point(460, 23);
            this.Check_Button.Name = "Check_Button";
            this.Check_Button.Size = new System.Drawing.Size(116, 53);
            this.Check_Button.TabIndex = 99;
            this.Check_Button.Text = "Check";
            this.Check_Button.UseVisualStyleBackColor = false;
            this.Check_Button.Click += new System.EventHandler(this.Check_Button_Click);
            // 
            // SudokuForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(677, 815);
            this.Controls.Add(this.Check_Button);
            this.Controls.Add(this.Reset_Button);
            this.Controls.Add(this.Sudoku1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textBox95);
            this.Controls.Add(this.textBox87);
            this.Controls.Add(this.textBox84);
            this.Controls.Add(this.textBox97);
            this.Controls.Add(this.textBox96);
            this.Controls.Add(this.textBox94);
            this.Controls.Add(this.textBox93);
            this.Controls.Add(this.textBox92);
            this.Controls.Add(this.textBox91);
            this.Controls.Add(this.textBox90);
            this.Controls.Add(this.textBox89);
            this.Controls.Add(this.textBox88);
            this.Controls.Add(this.textBox86);
            this.Controls.Add(this.textBox85);
            this.Controls.Add(this.textBox83);
            this.Controls.Add(this.textBox82);
            this.Controls.Add(this.eight8);
            this.Controls.Add(this.eight7);
            this.Controls.Add(this.eight6);
            this.Controls.Add(this.eight5);
            this.Controls.Add(this.eight4);
            this.Controls.Add(this.eight3);
            this.Controls.Add(this.eight2);
            this.Controls.Add(this.eight1);
            this.Controls.Add(this.eight0);
            this.Controls.Add(this.seven8);
            this.Controls.Add(this.seven7);
            this.Controls.Add(this.seven6);
            this.Controls.Add(this.seven5);
            this.Controls.Add(this.seven4);
            this.Controls.Add(this.seven3);
            this.Controls.Add(this.seven2);
            this.Controls.Add(this.seven1);
            this.Controls.Add(this.seven0);
            this.Controls.Add(this.six8);
            this.Controls.Add(this.six7);
            this.Controls.Add(this.six6);
            this.Controls.Add(this.six5);
            this.Controls.Add(this.six4);
            this.Controls.Add(this.six3);
            this.Controls.Add(this.six2);
            this.Controls.Add(this.six1);
            this.Controls.Add(this.six0);
            this.Controls.Add(this.five8);
            this.Controls.Add(this.five7);
            this.Controls.Add(this.five6);
            this.Controls.Add(this.five5);
            this.Controls.Add(this.five4);
            this.Controls.Add(this.five3);
            this.Controls.Add(this.five2);
            this.Controls.Add(this.five1);
            this.Controls.Add(this.five0);
            this.Controls.Add(this.four8);
            this.Controls.Add(this.four7);
            this.Controls.Add(this.four6);
            this.Controls.Add(this.four5);
            this.Controls.Add(this.four4);
            this.Controls.Add(this.four3);
            this.Controls.Add(this.four2);
            this.Controls.Add(this.four1);
            this.Controls.Add(this.four0);
            this.Controls.Add(this.three8);
            this.Controls.Add(this.three7);
            this.Controls.Add(this.three6);
            this.Controls.Add(this.three5);
            this.Controls.Add(this.three4);
            this.Controls.Add(this.three3);
            this.Controls.Add(this.three2);
            this.Controls.Add(this.three1);
            this.Controls.Add(this.three0);
            this.Controls.Add(this.two8);
            this.Controls.Add(this.two7);
            this.Controls.Add(this.two6);
            this.Controls.Add(this.two5);
            this.Controls.Add(this.two4);
            this.Controls.Add(this.two3);
            this.Controls.Add(this.two2);
            this.Controls.Add(this.two1);
            this.Controls.Add(this.two0);
            this.Controls.Add(this.one8);
            this.Controls.Add(this.one7);
            this.Controls.Add(this.one6);
            this.Controls.Add(this.one5);
            this.Controls.Add(this.one4);
            this.Controls.Add(this.one3);
            this.Controls.Add(this.one2);
            this.Controls.Add(this.one1);
            this.Controls.Add(this.one0);
            this.Controls.Add(this.zero8);
            this.Controls.Add(this.zero7);
            this.Controls.Add(this.zero6);
            this.Controls.Add(this.zero5);
            this.Controls.Add(this.zero4);
            this.Controls.Add(this.zero3);
            this.Controls.Add(this.zero2);
            this.Controls.Add(this.zero1);
            this.Controls.Add(this.zero0);
            this.Name = "SudokuForm";
            this.Text = "Sudoku";
            this.Load += new System.EventHandler(this.SudokuForm_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox zero0;
        private System.Windows.Forms.TextBox zero1;
        private System.Windows.Forms.TextBox zero3;
        private System.Windows.Forms.TextBox zero2;
        private System.Windows.Forms.TextBox zero5;
        private System.Windows.Forms.TextBox zero4;
        private System.Windows.Forms.TextBox zero7;
        private System.Windows.Forms.TextBox zero6;
        private System.Windows.Forms.TextBox zero8;
        private System.Windows.Forms.TextBox one8;
        private System.Windows.Forms.TextBox one7;
        private System.Windows.Forms.TextBox one6;
        private System.Windows.Forms.TextBox one5;
        private System.Windows.Forms.TextBox one4;
        private System.Windows.Forms.TextBox one3;
        private System.Windows.Forms.TextBox one2;
        private System.Windows.Forms.TextBox one1;
        private System.Windows.Forms.TextBox one0;
        private System.Windows.Forms.TextBox two8;
        private System.Windows.Forms.TextBox two7;
        private System.Windows.Forms.TextBox two6;
        private System.Windows.Forms.TextBox two5;
        private System.Windows.Forms.TextBox two4;
        private System.Windows.Forms.TextBox two3;
        private System.Windows.Forms.TextBox two2;
        private System.Windows.Forms.TextBox two1;
        private System.Windows.Forms.TextBox two0;
        private System.Windows.Forms.TextBox three8;
        private System.Windows.Forms.TextBox three7;
        private System.Windows.Forms.TextBox three6;
        private System.Windows.Forms.TextBox three5;
        private System.Windows.Forms.TextBox three4;
        private System.Windows.Forms.TextBox three3;
        private System.Windows.Forms.TextBox three2;
        private System.Windows.Forms.TextBox three1;
        private System.Windows.Forms.TextBox three0;
        private System.Windows.Forms.TextBox four8;
        private System.Windows.Forms.TextBox four7;
        private System.Windows.Forms.TextBox four6;
        private System.Windows.Forms.TextBox four5;
        private System.Windows.Forms.TextBox four4;
        private System.Windows.Forms.TextBox four3;
        private System.Windows.Forms.TextBox four2;
        private System.Windows.Forms.TextBox four1;
        private System.Windows.Forms.TextBox four0;
        private System.Windows.Forms.TextBox five8;
        private System.Windows.Forms.TextBox five7;
        private System.Windows.Forms.TextBox five6;
        private System.Windows.Forms.TextBox five5;
        private System.Windows.Forms.TextBox five4;
        private System.Windows.Forms.TextBox five3;
        private System.Windows.Forms.TextBox five2;
        private System.Windows.Forms.TextBox five1;
        private System.Windows.Forms.TextBox five0;
        private System.Windows.Forms.TextBox six8;
        private System.Windows.Forms.TextBox six7;
        private System.Windows.Forms.TextBox six6;
        private System.Windows.Forms.TextBox six5;
        private System.Windows.Forms.TextBox six4;
        private System.Windows.Forms.TextBox six3;
        private System.Windows.Forms.TextBox six2;
        private System.Windows.Forms.TextBox six1;
        private System.Windows.Forms.TextBox six0;
        private System.Windows.Forms.TextBox seven8;
        private System.Windows.Forms.TextBox seven7;
        private System.Windows.Forms.TextBox seven6;
        private System.Windows.Forms.TextBox seven5;
        private System.Windows.Forms.TextBox seven4;
        private System.Windows.Forms.TextBox seven3;
        private System.Windows.Forms.TextBox seven2;
        private System.Windows.Forms.TextBox seven1;
        private System.Windows.Forms.TextBox seven0;
        private System.Windows.Forms.TextBox eight8;
        private System.Windows.Forms.TextBox eight7;
        private System.Windows.Forms.TextBox eight6;
        private System.Windows.Forms.TextBox eight5;
        private System.Windows.Forms.TextBox eight4;
        private System.Windows.Forms.TextBox eight3;
        private System.Windows.Forms.TextBox eight2;
        private System.Windows.Forms.TextBox eight1;
        private System.Windows.Forms.TextBox eight0;
        private System.Windows.Forms.TextBox textBox82;
        private System.Windows.Forms.TextBox textBox83;
        private System.Windows.Forms.TextBox textBox84;
        private System.Windows.Forms.TextBox textBox85;
        private System.Windows.Forms.TextBox textBox86;
        private System.Windows.Forms.TextBox textBox87;
        private System.Windows.Forms.TextBox textBox88;
        private System.Windows.Forms.TextBox textBox89;
        private System.Windows.Forms.TextBox textBox90;
        private System.Windows.Forms.TextBox textBox91;
        private System.Windows.Forms.TextBox textBox92;
        private System.Windows.Forms.TextBox textBox93;
        private System.Windows.Forms.TextBox textBox94;
        private System.Windows.Forms.TextBox textBox95;
        private System.Windows.Forms.TextBox textBox96;
        private System.Windows.Forms.TextBox textBox97;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label Sudoku1;
        private System.Windows.Forms.Button Reset_Button;
        private System.Windows.Forms.Button Check_Button;
    }
}