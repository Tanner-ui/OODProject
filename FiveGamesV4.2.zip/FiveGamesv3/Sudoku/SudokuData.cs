﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FiveGames
{
    public class SudokuData
    {
        private List<string> puzzles = new List<string>();
        private Random rand = new Random();

        public SudokuData(string filePath)
        {
            LoadPuzzles(filePath);
        }

        private void LoadPuzzles(string filePath)
        {
            if (File.Exists(filePath))
            {
                string[] lines = File.ReadAllLines(filePath);
                foreach (string line in lines)
                {
                    if (line.Length == 81)
                        puzzles.Add(line);
                }
            }
            else
            {
                throw new FileNotFoundException("Puzzle file not found.");
            }
        }

        public string GetRandomPuzzle()
        {
            if (puzzles.Count == 0)
                throw new Exception("No puzzles loaded.");
            return puzzles[rand.Next(puzzles.Count)];
        }
    }
}
