﻿namespace HangmanForm
{
    partial class HangmanForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblWordDisplay = new System.Windows.Forms.Label();
            this.txtInput = new System.Windows.Forms.TextBox();
            this.btnGuess = new System.Windows.Forms.Button();
            this.btnRestart = new System.Windows.Forms.Button();
            this.lblIncorrectGuesses = new System.Windows.Forms.Label();
            this.hangmanImage = new System.Windows.Forms.PictureBox();
            this.lblGuessedLetters = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.hangmanImage)).BeginInit();
            this.SuspendLayout();
            // 
            // lblWordDisplay
            // 
            this.lblWordDisplay.AutoSize = true;
            this.lblWordDisplay.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F);
            this.lblWordDisplay.Location = new System.Drawing.Point(252, 89);
            this.lblWordDisplay.Name = "lblWordDisplay";
            this.lblWordDisplay.Size = new System.Drawing.Size(212, 37);
            this.lblWordDisplay.TabIndex = 0;
            this.lblWordDisplay.Text = "Word: _ _ _ _";
            // 
            // txtInput
            // 
            this.txtInput.Location = new System.Drawing.Point(290, 163);
            this.txtInput.MaxLength = 1;
            this.txtInput.Name = "txtInput";
            this.txtInput.Size = new System.Drawing.Size(100, 26);
            this.txtInput.TabIndex = 1;
            // 
            // btnGuess
            // 
            this.btnGuess.Location = new System.Drawing.Point(136, 231);
            this.btnGuess.Name = "btnGuess";
            this.btnGuess.Size = new System.Drawing.Size(75, 45);
            this.btnGuess.TabIndex = 2;
            this.btnGuess.Text = "Guess";
            this.btnGuess.UseVisualStyleBackColor = true;
            this.btnGuess.Click += new System.EventHandler(this.btnGuess_Click);
            // 
            // btnRestart
            // 
            this.btnRestart.Location = new System.Drawing.Point(22, 231);
            this.btnRestart.Name = "btnRestart";
            this.btnRestart.Size = new System.Drawing.Size(75, 45);
            this.btnRestart.TabIndex = 3;
            this.btnRestart.Text = "Restart";
            this.btnRestart.UseVisualStyleBackColor = true;
            this.btnRestart.Click += new System.EventHandler(this.btnRestart_Click);
            // 
            // lblIncorrectGuesses
            // 
            this.lblIncorrectGuesses.AutoSize = true;
            this.lblIncorrectGuesses.Location = new System.Drawing.Point(276, 31);
            this.lblIncorrectGuesses.Name = "lblIncorrectGuesses";
            this.lblIncorrectGuesses.Size = new System.Drawing.Size(157, 20);
            this.lblIncorrectGuesses.TabIndex = 4;
            this.lblIncorrectGuesses.Text = "Incorrect Guesses: 0";
            // 
            // hangmanImage
            // 
            this.hangmanImage.Location = new System.Drawing.Point(12, 12);
            this.hangmanImage.Name = "hangmanImage";
            this.hangmanImage.Size = new System.Drawing.Size(200, 200);
            this.hangmanImage.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.hangmanImage.TabIndex = 5;
            this.hangmanImage.TabStop = false;
            // 
            // lblGuessedLetters
            // 
            this.lblGuessedLetters.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblGuessedLetters.Location = new System.Drawing.Point(43, 406);
            this.lblGuessedLetters.Name = "lblGuessedLetters";
            this.lblGuessedLetters.Size = new System.Drawing.Size(819, 122);
            this.lblGuessedLetters.TabIndex = 6;
            // 
            // HangmanForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(742, 537);
            this.Controls.Add(this.lblGuessedLetters);
            this.Controls.Add(this.hangmanImage);
            this.Controls.Add(this.lblIncorrectGuesses);
            this.Controls.Add(this.btnRestart);
            this.Controls.Add(this.btnGuess);
            this.Controls.Add(this.txtInput);
            this.Controls.Add(this.lblWordDisplay);
            this.Name = "HangmanForm";
            this.Text = "Hangman Game";
            ((System.ComponentModel.ISupportInitialize)(this.hangmanImage)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblWordDisplay;
        private System.Windows.Forms.TextBox txtInput;
        private System.Windows.Forms.Button btnGuess;
        private System.Windows.Forms.Button btnRestart;
        private System.Windows.Forms.Label lblIncorrectGuesses;
        private System.Windows.Forms.PictureBox hangmanImage;
        private System.Windows.Forms.Label lblGuessedLetters;
    }
}

