﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace HangmanForm
{
    public partial class HangmanForm : Form
    {
        #region Creation/Loading
        private HangmanData hangmanGame = new HangmanData();

        public HangmanForm()
        {
            InitializeComponent();
            StartNewGame();
        }

        private void StartNewGame()
        {
            hangmanGame.StartNewGame();
            UpdateHangmanImage(0);
            UpdateDisplay();
            UpdateGuessedLetters();
        }
        #endregion Creation/Loading

        #region Clicks
        private void btnGuess_Click(object sender, EventArgs e)
        {
            if (txtInput.Text.Length == 1)
            {
                char guess = txtInput.Text.ToLower()[0];
                txtInput.Clear();

                if (!hangmanGame.GuessedLetters.Contains(guess))
                {
                    bool correct = hangmanGame.ProcessGuess(guess);
                    if (!correct)
                        UpdateHangmanImage(hangmanGame.IncorrectGuesses);

                    UpdateDisplay();
                    UpdateGuessedLetters();
                    CheckGameStatus();
                }
            }
        }

        private void btnRestart_Click(object sender, EventArgs e)
        {
            StartNewGame();
        }

        #endregion Clicks

        #region Update
        private void UpdateDisplay()
        {
            lblWordDisplay.Text = "Word: " + hangmanGame.DisplayWord;
            lblIncorrectGuesses.Text = $"Incorrect Guesses: {hangmanGame.IncorrectGuesses}/{hangmanGame.MaxIncorrectGuesses}";
        }

        private void UpdateHangmanImage(int stage)
        {
            string imagePath = $"hangman{stage}.png";
            if (System.IO.File.Exists(imagePath))
                hangmanImage.Image = Image.FromFile(imagePath);
        }

        private void UpdateGuessedLetters()
        {
            lblGuessedLetters.Text = "Guessed Letters: " + string.Join(", ", hangmanGame.GuessedLetters);
        }

        private void CheckGameStatus()
        {
            if (hangmanGame.IsGameWon)
            {
                MessageBox.Show("You Win!", "Hangman", MessageBoxButtons.OK, MessageBoxIcon.Information);
                StartNewGame();
            }
            else if (hangmanGame.IsGameOver)
            {
                MessageBox.Show($"Game Over! The word was {hangmanGame.SelectedWord}", "Hangman", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                StartNewGame();
            }
        }
        #endregion Update
    }
}