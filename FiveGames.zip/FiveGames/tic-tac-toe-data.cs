﻿using System;
using System.CodeDom;
using System.Security.Cryptography.X509Certificates;
// 1 = O's 2 = x's


public class TicData
{
    public static int[] arr = new int[9];
    public static int turn = 1;
    public static int turnNum = 0;
    public static bool gameover = false;
    Random random = new Random();
    public int random1;

    #region
    public void X(int x)
    {
        if (arr[x - 1] == 0 && gameover == false)
        {
            arr[x - 1] = turn;
            turnNum++;
        }
    }
    #endregion

    #region
    public void O()
    {
        if (turn == 2 && gameover == false)
        {
            while (turn == 2 && turnNum < 9)
            {
                random1 = random.Next(1, 10);
                if (arr[random1 - 1] == 0)
                {
                    arr[random1 - 1] = turn;
                    turn++;
                    turnNum++;
                }
            }
            turn--;
        }
    } 
    #endregion
 


}
