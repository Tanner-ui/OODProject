﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FiveGames;
using System.Windows.Forms;

namespace FiveGames
{
    public abstract class GameBase : Form
    {
        protected Label ScoreLabel;

        public void SetScoreLabel(Label label)
        {
            ScoreLabel = label;
            UpdateScoreDisplay();
        }

        public void UpdateScoreDisplay()
        {
            if (ScoreLabel != null)
            {
                ScoreLabel.Text = "Score: " + GetFormattedScore();
            }
        }

        protected abstract string GetFormattedScore();
    }
}

