﻿namespace FiveGames
{
    partial class Tic_Tac_Toe
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Tic_Tac_Toe));
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.tl = new System.Windows.Forms.Button();
            this.tm = new System.Windows.Forms.Button();
            this.tr = new System.Windows.Forms.Button();
            this.ml = new System.Windows.Forms.Button();
            this.mr = new System.Windows.Forms.Button();
            this.mm = new System.Windows.Forms.Button();
            this.bl = new System.Windows.Forms.Button();
            this.bm = new System.Windows.Forms.Button();
            this.br = new System.Windows.Forms.Button();
            this.end = new System.Windows.Forms.TextBox();
            this.restart = new System.Windows.Forms.Button();
            this.scoreLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(25, -25);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(896, 826);
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // tl
            // 
            this.tl.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.tl.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.tl.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.tl.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.tl.Location = new System.Drawing.Point(151, 106);
            this.tl.Name = "tl";
            this.tl.Size = new System.Drawing.Size(113, 122);
            this.tl.TabIndex = 1;
            this.tl.UseVisualStyleBackColor = false;
            this.tl.Click += new System.EventHandler(this.tl_Click);
            // 
            // tm
            // 
            this.tm.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.tm.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.tm.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.tm.Location = new System.Drawing.Point(285, 105);
            this.tm.Name = "tm";
            this.tm.Size = new System.Drawing.Size(113, 123);
            this.tm.TabIndex = 2;
            this.tm.UseVisualStyleBackColor = false;
            this.tm.Click += new System.EventHandler(this.tm_Click);
            // 
            // tr
            // 
            this.tr.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.tr.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.tr.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.tr.Location = new System.Drawing.Point(420, 106);
            this.tr.Name = "tr";
            this.tr.Size = new System.Drawing.Size(113, 122);
            this.tr.TabIndex = 3;
            this.tr.UseVisualStyleBackColor = false;
            this.tr.Click += new System.EventHandler(this.tr_Click);
            // 
            // ml
            // 
            this.ml.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.ml.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.ml.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.ml.Location = new System.Drawing.Point(151, 247);
            this.ml.Name = "ml";
            this.ml.Size = new System.Drawing.Size(113, 122);
            this.ml.TabIndex = 4;
            this.ml.UseVisualStyleBackColor = false;
            this.ml.Click += new System.EventHandler(this.ml_Click);
            // 
            // mr
            // 
            this.mr.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.mr.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.mr.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.mr.Location = new System.Drawing.Point(420, 247);
            this.mr.Name = "mr";
            this.mr.Size = new System.Drawing.Size(113, 122);
            this.mr.TabIndex = 5;
            this.mr.UseVisualStyleBackColor = false;
            this.mr.Click += new System.EventHandler(this.mr_Click);
            // 
            // mm
            // 
            this.mm.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.mm.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.mm.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.mm.Location = new System.Drawing.Point(285, 247);
            this.mm.Name = "mm";
            this.mm.Size = new System.Drawing.Size(113, 122);
            this.mm.TabIndex = 6;
            this.mm.UseVisualStyleBackColor = false;
            this.mm.Click += new System.EventHandler(this.mm_Click);
            // 
            // bl
            // 
            this.bl.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.bl.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.bl.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.bl.Location = new System.Drawing.Point(151, 384);
            this.bl.Name = "bl";
            this.bl.Size = new System.Drawing.Size(113, 122);
            this.bl.TabIndex = 7;
            this.bl.UseVisualStyleBackColor = false;
            this.bl.Click += new System.EventHandler(this.bl_Click);
            // 
            // bm
            // 
            this.bm.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.bm.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.bm.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.bm.Location = new System.Drawing.Point(285, 384);
            this.bm.Name = "bm";
            this.bm.Size = new System.Drawing.Size(113, 122);
            this.bm.TabIndex = 8;
            this.bm.UseVisualStyleBackColor = false;
            this.bm.Click += new System.EventHandler(this.bm_Click);
            // 
            // br
            // 
            this.br.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.br.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.br.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.br.Location = new System.Drawing.Point(420, 384);
            this.br.Name = "br";
            this.br.Size = new System.Drawing.Size(113, 122);
            this.br.TabIndex = 9;
            this.br.UseVisualStyleBackColor = false;
            this.br.Click += new System.EventHandler(this.br_Click);
            // 
            // end
            // 
            this.end.Location = new System.Drawing.Point(156, 554);
            this.end.Name = "end";
            this.end.Size = new System.Drawing.Size(376, 26);
            this.end.TabIndex = 10;
            // 
            // restart
            // 
            this.restart.Location = new System.Drawing.Point(272, 604);
            this.restart.Name = "restart";
            this.restart.Size = new System.Drawing.Size(137, 42);
            this.restart.TabIndex = 11;
            this.restart.Text = "restart";
            this.restart.UseVisualStyleBackColor = true;
            this.restart.Click += new System.EventHandler(this.restart_Click);
            // 
            // scoreLabel
            // 
            this.scoreLabel.AutoSize = true;
            this.scoreLabel.Location = new System.Drawing.Point(213, 34);
            this.scoreLabel.Name = "scoreLabel";
            this.scoreLabel.Size = new System.Drawing.Size(51, 20);
            this.scoreLabel.TabIndex = 12;
            this.scoreLabel.Text = "label1";
            // 
            // Tic_Tac_Toe
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(643, 666);
            this.Controls.Add(this.scoreLabel);
            this.Controls.Add(this.restart);
            this.Controls.Add(this.end);
            this.Controls.Add(this.br);
            this.Controls.Add(this.bm);
            this.Controls.Add(this.bl);
            this.Controls.Add(this.mm);
            this.Controls.Add(this.mr);
            this.Controls.Add(this.ml);
            this.Controls.Add(this.tr);
            this.Controls.Add(this.tm);
            this.Controls.Add(this.tl);
            this.Controls.Add(this.pictureBox1);
            this.Name = "Tic_Tac_Toe";
            this.Text = "Tic_Tac_Toe";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button tl;
        private System.Windows.Forms.Button tm;
        private System.Windows.Forms.Button tr;
        private System.Windows.Forms.Button ml;
        private System.Windows.Forms.Button mr;
        private System.Windows.Forms.Button mm;
        private System.Windows.Forms.Button bl;
        private System.Windows.Forms.Button bm;
        private System.Windows.Forms.Button br;
        private System.Windows.Forms.TextBox end;
        private System.Windows.Forms.Button restart;
        private System.Windows.Forms.Label scoreLabel;
    }
}