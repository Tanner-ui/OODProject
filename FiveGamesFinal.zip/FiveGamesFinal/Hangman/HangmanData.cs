﻿using System;
using System.Collections.Generic;
using System.IO;

namespace HangmanForm
{
    public class HangmanData
    {
        #region Variables
        private List<string> words = new List<string>();
        private string selectedWord;
        private char[] displayWord;
        private List<char> guessedLetters = new List<char>();
        private int incorrectGuesses = 0;
        private const int maxIncorrectGuesses = 6;

        public string DisplayWord => new string(displayWord);
        public int IncorrectGuesses => incorrectGuesses;
        public int MaxIncorrectGuesses => maxIncorrectGuesses;
        public bool IsGameOver => incorrectGuesses >= maxIncorrectGuesses;
        public bool IsGameWon => DisplayWord == selectedWord;
        public string SelectedWord => selectedWord;
        public List<char> GuessedLetters => guessedLetters;

        #endregion Variables

        #region Loading
        public void StartNewGame()
        {
            LoadWordsFromFile();
            if (words.Count == 0)
                throw new Exception("No words found in WordBase.txt!");

            Random rand = new Random();
            selectedWord = words[rand.Next(words.Count)];
            displayWord = new string('_', selectedWord.Length).ToCharArray();
            incorrectGuesses = 0;
            guessedLetters.Clear();
        }

        private void LoadWordsFromFile()
        {
            words.Clear();
            string filePath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "WordBase.txt");

            if (File.Exists(filePath))
            {
                foreach (string line in File.ReadAllLines(filePath))
                {
                    string word = line.Trim().ToLower();
                    if (!string.IsNullOrEmpty(word))
                        words.Add(word);
                }
            }
            else
            {
                throw new FileNotFoundException("WordBase.txt not found at: " + filePath);
            }
        }
        #endregion Loading

        #region Guess
        public bool ProcessGuess(char guess)
        {
            bool correct = false;

            if (!guessedLetters.Contains(guess))
            {
                guessedLetters.Add(guess);

                for (int i = 0; i < selectedWord.Length; i++)
                {
                    if (selectedWord[i] == guess)
                    {
                        displayWord[i] = guess;
                        correct = true;
                    }
                }

                if (!correct)
                    incorrectGuesses++;
            }

            return correct;
        }
        #endregion Guess
    }
}