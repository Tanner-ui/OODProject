﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Diagnostics;
using System.Windows.Forms;
using FiveGames;

namespace FiveGames
{
    public partial class SudokuForm : GameBase
    {
        private SudokuData sudokuData;
        private int[,] currentBoard = new int[9, 9]; //This array holds the current game data and should update when a new number is added.
        private DateTime startTime;

        #region Loading
        public SudokuForm()
        {
            InitializeComponent();
            sudokuData = new SudokuData("puzzles.txt");
            SetScoreLabel(labelScore); // Set this label in the designer
            startTime = DateTime.Now;
            StartTimer(); // For live updates

            foreach (Control control in this.Controls)
            {
                if (control is TextBox)
                {
                    control.TextChanged += TextBox_TextChanged;
                }
            }
        }
        private void StartTimer()
        {
            Timer timer = new Timer();
            timer.Interval = 1000;
            timer.Tick += (s, e) => UpdateScoreDisplay();
            timer.Start();
        }

        protected override string GetFormattedScore()
        {
            TimeSpan elapsed = DateTime.Now - startTime;
            return $"{elapsed.Minutes:D2}:{elapsed.Seconds:D2}";
        }

        private void SudokuForm_Load(object sender, EventArgs e)
        {
            sudokuData = new SudokuData("puzzles.txt");
            string puzzle = sudokuData.GetRandomPuzzle();
            LoadPuzzleToGrid(puzzle);
        }

        private void LoadPuzzleToGrid(string puzzle)
        {
            for (int i = 0; i < 81; i++)
            {
                string controlName = GetControlName(i);
                Control[] matches = this.Controls.Find(controlName, true);

                int row = i / 9;
                int col = i % 9;

                if (matches.Length > 0 && matches[0] is TextBox textBox)
                {
                    char c = puzzle[i];
                    if (c == '0')
                    {
                        textBox.ReadOnly = false;
                        textBox.Text = "";
                        currentBoard[row, col] = 0;
                    }
                    else
                    {
                        textBox.ReadOnly = true;
                        textBox.Text = c.ToString();
                        currentBoard[row, col] = c - '0';
                    }
                }
            }
        }
        #endregion Loading

        #region Updates
        private void TextBox_TextChanged(object sender, EventArgs e)
        {
            TextBox textBox = sender as TextBox;

            if (textBox != null)
            {
                if (string.IsNullOrEmpty(textBox.Text))
                {
                    UpdateBoardFromControl(textBox, 0);
                    return;
                }

                if (!int.TryParse(textBox.Text, out int number) || number < 1 || number > 9)
                {
                    textBox.Text = "";
                    MessageBox.Show("Please enter a valid number between 1 and 9.");
                }
                else
                {
                    UpdateBoardFromControl(textBox, number);
                    //PrintCurrentBoard();
                }
            }
        }
        #endregion Updates

        #region Helpers
        //These functions are kinda like translators between the in-code arrays and the actually gameboard.
        private string GetControlName(int index)
        {
            string[] names = { "zero", "one", "two", "three", "four", "five", "six", "seven", "eight" };
            int row = index / 9;
            int col = index % 9;
            return names[row] + col.ToString();
        }

        private void UpdateBoardFromControl(TextBox textBox, int value)
        {
            string name = textBox.Name;
            string[] names = { "zero", "one", "two", "three", "four", "five", "six", "seven", "eight" };

            for (int row = 0; row < 9; row++)
            {
                if (name.StartsWith(names[row]))
                {
                    if (int.TryParse(name.Substring(names[row].Length), out int col))
                    {
                        currentBoard[row, col] = value;
                    }
                    break;
                }
            }
        }
        #endregion Helpers

        #region debug
        private void PrintCurrentBoard()
        {
            string boardText = "";
            for (int i = 0; i < 9; i++)
            {
                for (int j = 0; j < 9; j++)
                {
                    boardText += currentBoard[i, j] + " ";
                }
                boardText += "\n";
            }

            MessageBox.Show(boardText);
        }
        #endregion debug

        private void Check_Button_Click(object sender, EventArgs e)
        {
            bool win = true;
            //int x = currentBoard[0, 0];
            //int y = currentBoard[1, 0];
            //MessageBox.Show(x.ToString() + y.ToString());

            for (int row = 0; row < 9; row++)
            {
                for(int col = 0; col < 9; col++)
                {
                    if (currentBoard[row,col] == 0)
                    {
                        win = false;
                    }
                }
            }

              for (int col = 0; col < 9; col++)
            {
                for (int row1 = 0; row1 < 9; row1++)
                {
                    for (int row2 = 0; row2 < 9; row2++)
                    {
                        if (currentBoard[row1, col] == currentBoard[row2, col] && row1 != row2)
                        {
                            win = false;
                            break;
                        }
                    }
                    if (win == false)
                    { break; }
                }
                if (win == false)
                { break; }
            }
            for (int row = 0; row < 9; row++)
            {
                for (int col1 = 0; col1 < 9; col1++)
                {
                    for (int col2 = 0; col2 < 9; col2++)
                    {
                        if (currentBoard[row, col1] == currentBoard[row, col2] && col1 != col2)
                        {
                            win = false;
                            break;
                        }
                    }
                    if (win == false)
                    { break; }
                }
                if (win == false)
                { break; }
            }

            int rowcheck = 3;
            int colcheck = 3;

            while (rowcheck <= 9)
            {
                if (colcheck > 9)
                {
                    rowcheck += 3;
                    colcheck = 3;
                }
                if (rowcheck > 9)
                    break;
                for (int row1 = rowcheck - 3; row1 < rowcheck; row1++)
                {
                    for(int col1 = colcheck - 3; col1 < colcheck; col1++)
                    {

                        for (int row2 = rowcheck - 3; row2 < rowcheck; row2++)
                        {
                            for (int col2 = colcheck - 3; col2 < colcheck; col2++)
                            {
                                if (currentBoard[row1, col1] == currentBoard[row2, col2])
                                {
                                    if (row1 != row2 && col1 != col2)
                                    {
                                        win = false;
                                    }
                                }
                            }
                        }

                    }
                }
                colcheck += 3;
            }

            if (win == true)
            {
                MessageBox.Show("You win!");
                this.Close();
            }
            else
            {
                MessageBox.Show("Incorrect answer");
            }

        }
    }
}

