﻿namespace FiveGames
{
    partial class Sudoku
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Zero0 = new System.Windows.Forms.TextBox();
            this.Zero1 = new System.Windows.Forms.TextBox();
            this.Zero3 = new System.Windows.Forms.TextBox();
            this.Zero2 = new System.Windows.Forms.TextBox();
            this.Zero5 = new System.Windows.Forms.TextBox();
            this.Zero4 = new System.Windows.Forms.TextBox();
            this.zero7 = new System.Windows.Forms.TextBox();
            this.zero6 = new System.Windows.Forms.TextBox();
            this.zero8 = new System.Windows.Forms.TextBox();
            this.One8 = new System.Windows.Forms.TextBox();
            this.One7 = new System.Windows.Forms.TextBox();
            this.One6 = new System.Windows.Forms.TextBox();
            this.One5 = new System.Windows.Forms.TextBox();
            this.One4 = new System.Windows.Forms.TextBox();
            this.One3 = new System.Windows.Forms.TextBox();
            this.One2 = new System.Windows.Forms.TextBox();
            this.One1 = new System.Windows.Forms.TextBox();
            this.One0 = new System.Windows.Forms.TextBox();
            this.Two8 = new System.Windows.Forms.TextBox();
            this.Two7 = new System.Windows.Forms.TextBox();
            this.Two6 = new System.Windows.Forms.TextBox();
            this.Two5 = new System.Windows.Forms.TextBox();
            this.Two4 = new System.Windows.Forms.TextBox();
            this.Two3 = new System.Windows.Forms.TextBox();
            this.Two2 = new System.Windows.Forms.TextBox();
            this.Two1 = new System.Windows.Forms.TextBox();
            this.Two0 = new System.Windows.Forms.TextBox();
            this.Three8 = new System.Windows.Forms.TextBox();
            this.Three7 = new System.Windows.Forms.TextBox();
            this.Three6 = new System.Windows.Forms.TextBox();
            this.Three5 = new System.Windows.Forms.TextBox();
            this.Three4 = new System.Windows.Forms.TextBox();
            this.Three3 = new System.Windows.Forms.TextBox();
            this.Three2 = new System.Windows.Forms.TextBox();
            this.Three1 = new System.Windows.Forms.TextBox();
            this.Three0 = new System.Windows.Forms.TextBox();
            this.Four8 = new System.Windows.Forms.TextBox();
            this.Four7 = new System.Windows.Forms.TextBox();
            this.Four6 = new System.Windows.Forms.TextBox();
            this.Four5 = new System.Windows.Forms.TextBox();
            this.Four4 = new System.Windows.Forms.TextBox();
            this.Four3 = new System.Windows.Forms.TextBox();
            this.Four2 = new System.Windows.Forms.TextBox();
            this.Four1 = new System.Windows.Forms.TextBox();
            this.Four0 = new System.Windows.Forms.TextBox();
            this.Five8 = new System.Windows.Forms.TextBox();
            this.Five7 = new System.Windows.Forms.TextBox();
            this.Five6 = new System.Windows.Forms.TextBox();
            this.Five5 = new System.Windows.Forms.TextBox();
            this.Five4 = new System.Windows.Forms.TextBox();
            this.Five3 = new System.Windows.Forms.TextBox();
            this.Five2 = new System.Windows.Forms.TextBox();
            this.Five1 = new System.Windows.Forms.TextBox();
            this.Five0 = new System.Windows.Forms.TextBox();
            this.Six8 = new System.Windows.Forms.TextBox();
            this.Six7 = new System.Windows.Forms.TextBox();
            this.Six6 = new System.Windows.Forms.TextBox();
            this.Six5 = new System.Windows.Forms.TextBox();
            this.Six4 = new System.Windows.Forms.TextBox();
            this.Six3 = new System.Windows.Forms.TextBox();
            this.Six2 = new System.Windows.Forms.TextBox();
            this.Six1 = new System.Windows.Forms.TextBox();
            this.Six0 = new System.Windows.Forms.TextBox();
            this.Seven8 = new System.Windows.Forms.TextBox();
            this.Seven7 = new System.Windows.Forms.TextBox();
            this.Seven6 = new System.Windows.Forms.TextBox();
            this.Seven5 = new System.Windows.Forms.TextBox();
            this.Seven4 = new System.Windows.Forms.TextBox();
            this.Seven3 = new System.Windows.Forms.TextBox();
            this.Seven2 = new System.Windows.Forms.TextBox();
            this.Seven1 = new System.Windows.Forms.TextBox();
            this.Seven0 = new System.Windows.Forms.TextBox();
            this.Eight8 = new System.Windows.Forms.TextBox();
            this.Eight7 = new System.Windows.Forms.TextBox();
            this.Eight6 = new System.Windows.Forms.TextBox();
            this.Eight5 = new System.Windows.Forms.TextBox();
            this.Eight4 = new System.Windows.Forms.TextBox();
            this.Eight3 = new System.Windows.Forms.TextBox();
            this.Eight2 = new System.Windows.Forms.TextBox();
            this.Eight1 = new System.Windows.Forms.TextBox();
            this.Eight0 = new System.Windows.Forms.TextBox();
            this.textBox82 = new System.Windows.Forms.TextBox();
            this.textBox83 = new System.Windows.Forms.TextBox();
            this.textBox84 = new System.Windows.Forms.TextBox();
            this.textBox85 = new System.Windows.Forms.TextBox();
            this.textBox86 = new System.Windows.Forms.TextBox();
            this.textBox87 = new System.Windows.Forms.TextBox();
            this.textBox88 = new System.Windows.Forms.TextBox();
            this.textBox89 = new System.Windows.Forms.TextBox();
            this.textBox90 = new System.Windows.Forms.TextBox();
            this.textBox91 = new System.Windows.Forms.TextBox();
            this.textBox92 = new System.Windows.Forms.TextBox();
            this.textBox93 = new System.Windows.Forms.TextBox();
            this.textBox94 = new System.Windows.Forms.TextBox();
            this.textBox95 = new System.Windows.Forms.TextBox();
            this.textBox96 = new System.Windows.Forms.TextBox();
            this.textBox97 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.Sudoku1 = new System.Windows.Forms.Label();
            this.Reset_Button = new System.Windows.Forms.Button();
            this.Check_Button = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // Zero0
            // 
            this.Zero0.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.Zero0.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.Zero0.Font = new System.Drawing.Font("Stencil", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Zero0.ForeColor = System.Drawing.SystemColors.WindowText;
            this.Zero0.Location = new System.Drawing.Point(48, 157);
            this.Zero0.Multiline = true;
            this.Zero0.Name = "Zero0";
            this.Zero0.Size = new System.Drawing.Size(50, 49);
            this.Zero0.TabIndex = 0;
            this.Zero0.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Zero0.TextChanged += new System.EventHandler(this.Zero0_TextChanged);
            // 
            // Zero1
            // 
            this.Zero1.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.Zero1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.Zero1.Font = new System.Drawing.Font("Stencil", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Zero1.Location = new System.Drawing.Point(113, 157);
            this.Zero1.Multiline = true;
            this.Zero1.Name = "Zero1";
            this.Zero1.Size = new System.Drawing.Size(50, 49);
            this.Zero1.TabIndex = 1;
            this.Zero1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Zero1.TextChanged += new System.EventHandler(this.Zero1_TextChanged);
            // 
            // Zero3
            // 
            this.Zero3.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.Zero3.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.Zero3.Font = new System.Drawing.Font("Stencil", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Zero3.Location = new System.Drawing.Point(243, 157);
            this.Zero3.Multiline = true;
            this.Zero3.Name = "Zero3";
            this.Zero3.Size = new System.Drawing.Size(50, 49);
            this.Zero3.TabIndex = 3;
            this.Zero3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Zero3.TextChanged += new System.EventHandler(this.Zero3_TextChanged);
            // 
            // Zero2
            // 
            this.Zero2.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.Zero2.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.Zero2.Font = new System.Drawing.Font("Stencil", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Zero2.Location = new System.Drawing.Point(178, 157);
            this.Zero2.Multiline = true;
            this.Zero2.Name = "Zero2";
            this.Zero2.Size = new System.Drawing.Size(50, 49);
            this.Zero2.TabIndex = 2;
            this.Zero2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Zero2.TextChanged += new System.EventHandler(this.Zero2_TextChanged);
            // 
            // Zero5
            // 
            this.Zero5.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.Zero5.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.Zero5.Font = new System.Drawing.Font("Stencil", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Zero5.Location = new System.Drawing.Point(374, 157);
            this.Zero5.Multiline = true;
            this.Zero5.Name = "Zero5";
            this.Zero5.Size = new System.Drawing.Size(50, 49);
            this.Zero5.TabIndex = 5;
            this.Zero5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Zero5.TextChanged += new System.EventHandler(this.Zero5_TextChanged);
            // 
            // Zero4
            // 
            this.Zero4.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.Zero4.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.Zero4.Font = new System.Drawing.Font("Stencil", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Zero4.Location = new System.Drawing.Point(309, 157);
            this.Zero4.Multiline = true;
            this.Zero4.Name = "Zero4";
            this.Zero4.Size = new System.Drawing.Size(50, 49);
            this.Zero4.TabIndex = 4;
            this.Zero4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Zero4.TextChanged += new System.EventHandler(this.Zero4_TextChanged);
            // 
            // zero7
            // 
            this.zero7.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.zero7.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.zero7.Font = new System.Drawing.Font("Stencil", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.zero7.Location = new System.Drawing.Point(506, 157);
            this.zero7.Multiline = true;
            this.zero7.Name = "zero7";
            this.zero7.Size = new System.Drawing.Size(50, 49);
            this.zero7.TabIndex = 7;
            this.zero7.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.zero7.TextChanged += new System.EventHandler(this.zero7_TextChanged);
            // 
            // zero6
            // 
            this.zero6.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.zero6.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.zero6.Font = new System.Drawing.Font("Stencil", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.zero6.Location = new System.Drawing.Point(441, 157);
            this.zero6.Multiline = true;
            this.zero6.Name = "zero6";
            this.zero6.Size = new System.Drawing.Size(50, 49);
            this.zero6.TabIndex = 6;
            this.zero6.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.zero6.TextChanged += new System.EventHandler(this.zero6_TextChanged);
            // 
            // zero8
            // 
            this.zero8.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.zero8.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.zero8.Font = new System.Drawing.Font("Stencil", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.zero8.Location = new System.Drawing.Point(572, 157);
            this.zero8.Multiline = true;
            this.zero8.Name = "zero8";
            this.zero8.Size = new System.Drawing.Size(50, 49);
            this.zero8.TabIndex = 8;
            this.zero8.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.zero8.TextChanged += new System.EventHandler(this.zero8_TextChanged);
            // 
            // One8
            // 
            this.One8.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.One8.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.One8.Font = new System.Drawing.Font("Stencil", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.One8.Location = new System.Drawing.Point(572, 227);
            this.One8.Multiline = true;
            this.One8.Name = "One8";
            this.One8.Size = new System.Drawing.Size(50, 49);
            this.One8.TabIndex = 17;
            this.One8.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.One8.TextChanged += new System.EventHandler(this.One8_TextChanged);
            // 
            // One7
            // 
            this.One7.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.One7.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.One7.Font = new System.Drawing.Font("Stencil", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.One7.Location = new System.Drawing.Point(506, 227);
            this.One7.Multiline = true;
            this.One7.Name = "One7";
            this.One7.Size = new System.Drawing.Size(50, 49);
            this.One7.TabIndex = 16;
            this.One7.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.One7.TextChanged += new System.EventHandler(this.One7_TextChanged);
            // 
            // One6
            // 
            this.One6.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.One6.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.One6.Font = new System.Drawing.Font("Stencil", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.One6.Location = new System.Drawing.Point(441, 227);
            this.One6.Multiline = true;
            this.One6.Name = "One6";
            this.One6.Size = new System.Drawing.Size(50, 49);
            this.One6.TabIndex = 15;
            this.One6.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.One6.TextChanged += new System.EventHandler(this.One6_TextChanged);
            // 
            // One5
            // 
            this.One5.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.One5.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.One5.Font = new System.Drawing.Font("Stencil", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.One5.Location = new System.Drawing.Point(374, 227);
            this.One5.Multiline = true;
            this.One5.Name = "One5";
            this.One5.Size = new System.Drawing.Size(50, 49);
            this.One5.TabIndex = 14;
            this.One5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.One5.TextChanged += new System.EventHandler(this.One5_TextChanged);
            // 
            // One4
            // 
            this.One4.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.One4.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.One4.Font = new System.Drawing.Font("Stencil", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.One4.Location = new System.Drawing.Point(309, 227);
            this.One4.Multiline = true;
            this.One4.Name = "One4";
            this.One4.Size = new System.Drawing.Size(50, 49);
            this.One4.TabIndex = 13;
            this.One4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.One4.TextChanged += new System.EventHandler(this.One4_TextChanged);
            // 
            // One3
            // 
            this.One3.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.One3.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.One3.Font = new System.Drawing.Font("Stencil", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.One3.Location = new System.Drawing.Point(243, 227);
            this.One3.Multiline = true;
            this.One3.Name = "One3";
            this.One3.Size = new System.Drawing.Size(50, 49);
            this.One3.TabIndex = 12;
            this.One3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.One3.TextChanged += new System.EventHandler(this.One3_TextChanged);
            // 
            // One2
            // 
            this.One2.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.One2.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.One2.Font = new System.Drawing.Font("Stencil", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.One2.Location = new System.Drawing.Point(178, 227);
            this.One2.Multiline = true;
            this.One2.Name = "One2";
            this.One2.Size = new System.Drawing.Size(50, 49);
            this.One2.TabIndex = 11;
            this.One2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.One2.TextChanged += new System.EventHandler(this.One2_TextChanged);
            // 
            // One1
            // 
            this.One1.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.One1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.One1.Font = new System.Drawing.Font("Stencil", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.One1.Location = new System.Drawing.Point(113, 227);
            this.One1.Multiline = true;
            this.One1.Name = "One1";
            this.One1.Size = new System.Drawing.Size(50, 49);
            this.One1.TabIndex = 10;
            this.One1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.One1.TextChanged += new System.EventHandler(this.One1_TextChanged);
            // 
            // One0
            // 
            this.One0.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.One0.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.One0.Font = new System.Drawing.Font("Stencil", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.One0.Location = new System.Drawing.Point(48, 227);
            this.One0.Multiline = true;
            this.One0.Name = "One0";
            this.One0.Size = new System.Drawing.Size(50, 49);
            this.One0.TabIndex = 9;
            this.One0.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.One0.TextChanged += new System.EventHandler(this.One0_TextChanged);
            // 
            // Two8
            // 
            this.Two8.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.Two8.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.Two8.Font = new System.Drawing.Font("Stencil", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Two8.Location = new System.Drawing.Point(572, 299);
            this.Two8.Multiline = true;
            this.Two8.Name = "Two8";
            this.Two8.Size = new System.Drawing.Size(50, 49);
            this.Two8.TabIndex = 26;
            this.Two8.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Two8.TextChanged += new System.EventHandler(this.Two8_TextChanged);
            // 
            // Two7
            // 
            this.Two7.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.Two7.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.Two7.Font = new System.Drawing.Font("Stencil", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Two7.Location = new System.Drawing.Point(506, 299);
            this.Two7.Multiline = true;
            this.Two7.Name = "Two7";
            this.Two7.Size = new System.Drawing.Size(50, 49);
            this.Two7.TabIndex = 25;
            this.Two7.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Two7.TextChanged += new System.EventHandler(this.Two7_TextChanged);
            // 
            // Two6
            // 
            this.Two6.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.Two6.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.Two6.Font = new System.Drawing.Font("Stencil", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Two6.Location = new System.Drawing.Point(441, 299);
            this.Two6.Multiline = true;
            this.Two6.Name = "Two6";
            this.Two6.Size = new System.Drawing.Size(50, 49);
            this.Two6.TabIndex = 24;
            this.Two6.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Two6.TextChanged += new System.EventHandler(this.Two6_TextChanged);
            // 
            // Two5
            // 
            this.Two5.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.Two5.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.Two5.Font = new System.Drawing.Font("Stencil", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Two5.Location = new System.Drawing.Point(374, 299);
            this.Two5.Multiline = true;
            this.Two5.Name = "Two5";
            this.Two5.Size = new System.Drawing.Size(50, 49);
            this.Two5.TabIndex = 23;
            this.Two5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Two5.TextChanged += new System.EventHandler(this.Two5_TextChanged);
            // 
            // Two4
            // 
            this.Two4.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.Two4.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.Two4.Font = new System.Drawing.Font("Stencil", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Two4.Location = new System.Drawing.Point(309, 299);
            this.Two4.Multiline = true;
            this.Two4.Name = "Two4";
            this.Two4.Size = new System.Drawing.Size(50, 49);
            this.Two4.TabIndex = 22;
            this.Two4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Two4.TextChanged += new System.EventHandler(this.Two4_TextChanged);
            // 
            // Two3
            // 
            this.Two3.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.Two3.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.Two3.Font = new System.Drawing.Font("Stencil", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Two3.Location = new System.Drawing.Point(243, 299);
            this.Two3.Multiline = true;
            this.Two3.Name = "Two3";
            this.Two3.Size = new System.Drawing.Size(50, 49);
            this.Two3.TabIndex = 21;
            this.Two3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Two3.TextChanged += new System.EventHandler(this.Two3_TextChanged);
            // 
            // Two2
            // 
            this.Two2.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.Two2.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.Two2.Font = new System.Drawing.Font("Stencil", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Two2.Location = new System.Drawing.Point(178, 299);
            this.Two2.Multiline = true;
            this.Two2.Name = "Two2";
            this.Two2.Size = new System.Drawing.Size(50, 49);
            this.Two2.TabIndex = 20;
            this.Two2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Two2.TextChanged += new System.EventHandler(this.Two2_TextChanged);
            // 
            // Two1
            // 
            this.Two1.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.Two1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.Two1.Font = new System.Drawing.Font("Stencil", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Two1.Location = new System.Drawing.Point(113, 299);
            this.Two1.Multiline = true;
            this.Two1.Name = "Two1";
            this.Two1.Size = new System.Drawing.Size(50, 49);
            this.Two1.TabIndex = 19;
            this.Two1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Two1.TextChanged += new System.EventHandler(this.Two1_TextChanged);
            // 
            // Two0
            // 
            this.Two0.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.Two0.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.Two0.Font = new System.Drawing.Font("Stencil", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Two0.Location = new System.Drawing.Point(48, 299);
            this.Two0.Multiline = true;
            this.Two0.Name = "Two0";
            this.Two0.Size = new System.Drawing.Size(50, 49);
            this.Two0.TabIndex = 18;
            this.Two0.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Two0.TextChanged += new System.EventHandler(this.Two0_TextChanged);
            // 
            // Three8
            // 
            this.Three8.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.Three8.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.Three8.Font = new System.Drawing.Font("Stencil", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Three8.Location = new System.Drawing.Point(572, 370);
            this.Three8.Multiline = true;
            this.Three8.Name = "Three8";
            this.Three8.Size = new System.Drawing.Size(50, 49);
            this.Three8.TabIndex = 35;
            this.Three8.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Three8.TextChanged += new System.EventHandler(this.Three8_TextChanged);
            // 
            // Three7
            // 
            this.Three7.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.Three7.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.Three7.Font = new System.Drawing.Font("Stencil", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Three7.Location = new System.Drawing.Point(506, 370);
            this.Three7.Multiline = true;
            this.Three7.Name = "Three7";
            this.Three7.Size = new System.Drawing.Size(50, 49);
            this.Three7.TabIndex = 34;
            this.Three7.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Three7.TextChanged += new System.EventHandler(this.Three7_TextChanged);
            // 
            // Three6
            // 
            this.Three6.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.Three6.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.Three6.Font = new System.Drawing.Font("Stencil", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Three6.Location = new System.Drawing.Point(441, 370);
            this.Three6.Multiline = true;
            this.Three6.Name = "Three6";
            this.Three6.Size = new System.Drawing.Size(50, 49);
            this.Three6.TabIndex = 33;
            this.Three6.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Three6.TextChanged += new System.EventHandler(this.Three6_TextChanged);
            // 
            // Three5
            // 
            this.Three5.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.Three5.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.Three5.Font = new System.Drawing.Font("Stencil", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Three5.Location = new System.Drawing.Point(374, 370);
            this.Three5.Multiline = true;
            this.Three5.Name = "Three5";
            this.Three5.Size = new System.Drawing.Size(50, 49);
            this.Three5.TabIndex = 32;
            this.Three5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Three5.TextChanged += new System.EventHandler(this.Three5_TextChanged);
            // 
            // Three4
            // 
            this.Three4.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.Three4.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.Three4.Font = new System.Drawing.Font("Stencil", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Three4.Location = new System.Drawing.Point(309, 370);
            this.Three4.Multiline = true;
            this.Three4.Name = "Three4";
            this.Three4.Size = new System.Drawing.Size(50, 49);
            this.Three4.TabIndex = 31;
            this.Three4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Three4.TextChanged += new System.EventHandler(this.Three4_TextChanged);
            // 
            // Three3
            // 
            this.Three3.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.Three3.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.Three3.Font = new System.Drawing.Font("Stencil", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Three3.Location = new System.Drawing.Point(243, 370);
            this.Three3.Multiline = true;
            this.Three3.Name = "Three3";
            this.Three3.Size = new System.Drawing.Size(50, 49);
            this.Three3.TabIndex = 30;
            this.Three3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Three3.TextChanged += new System.EventHandler(this.Three3_TextChanged);
            // 
            // Three2
            // 
            this.Three2.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.Three2.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.Three2.Font = new System.Drawing.Font("Stencil", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Three2.Location = new System.Drawing.Point(178, 370);
            this.Three2.Multiline = true;
            this.Three2.Name = "Three2";
            this.Three2.Size = new System.Drawing.Size(50, 49);
            this.Three2.TabIndex = 29;
            this.Three2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Three2.TextChanged += new System.EventHandler(this.Three2_TextChanged);
            // 
            // Three1
            // 
            this.Three1.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.Three1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.Three1.Font = new System.Drawing.Font("Stencil", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Three1.Location = new System.Drawing.Point(113, 370);
            this.Three1.Multiline = true;
            this.Three1.Name = "Three1";
            this.Three1.Size = new System.Drawing.Size(50, 49);
            this.Three1.TabIndex = 28;
            this.Three1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Three1.TextChanged += new System.EventHandler(this.Three1_TextChanged);
            // 
            // Three0
            // 
            this.Three0.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.Three0.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.Three0.Font = new System.Drawing.Font("Stencil", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Three0.Location = new System.Drawing.Point(48, 370);
            this.Three0.Multiline = true;
            this.Three0.Name = "Three0";
            this.Three0.Size = new System.Drawing.Size(50, 49);
            this.Three0.TabIndex = 27;
            this.Three0.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Three0.TextChanged += new System.EventHandler(this.Three0_TextChanged);
            // 
            // Four8
            // 
            this.Four8.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.Four8.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.Four8.Font = new System.Drawing.Font("Stencil", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Four8.Location = new System.Drawing.Point(572, 442);
            this.Four8.Multiline = true;
            this.Four8.Name = "Four8";
            this.Four8.Size = new System.Drawing.Size(50, 49);
            this.Four8.TabIndex = 44;
            this.Four8.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Four8.TextChanged += new System.EventHandler(this.Four8_TextChanged);
            // 
            // Four7
            // 
            this.Four7.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.Four7.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.Four7.Font = new System.Drawing.Font("Stencil", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Four7.Location = new System.Drawing.Point(506, 442);
            this.Four7.Multiline = true;
            this.Four7.Name = "Four7";
            this.Four7.Size = new System.Drawing.Size(50, 49);
            this.Four7.TabIndex = 43;
            this.Four7.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Four7.TextChanged += new System.EventHandler(this.Four7_TextChanged);
            // 
            // Four6
            // 
            this.Four6.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.Four6.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.Four6.Font = new System.Drawing.Font("Stencil", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Four6.Location = new System.Drawing.Point(441, 442);
            this.Four6.Multiline = true;
            this.Four6.Name = "Four6";
            this.Four6.Size = new System.Drawing.Size(50, 49);
            this.Four6.TabIndex = 42;
            this.Four6.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Four6.TextChanged += new System.EventHandler(this.Four6_TextChanged);
            // 
            // Four5
            // 
            this.Four5.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.Four5.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.Four5.Font = new System.Drawing.Font("Stencil", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Four5.Location = new System.Drawing.Point(374, 442);
            this.Four5.Multiline = true;
            this.Four5.Name = "Four5";
            this.Four5.Size = new System.Drawing.Size(50, 49);
            this.Four5.TabIndex = 41;
            this.Four5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Four5.TextChanged += new System.EventHandler(this.Four5_TextChanged);
            // 
            // Four4
            // 
            this.Four4.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.Four4.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.Four4.Font = new System.Drawing.Font("Stencil", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Four4.Location = new System.Drawing.Point(309, 442);
            this.Four4.Multiline = true;
            this.Four4.Name = "Four4";
            this.Four4.Size = new System.Drawing.Size(50, 49);
            this.Four4.TabIndex = 40;
            this.Four4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Four4.TextChanged += new System.EventHandler(this.Four4_TextChanged);
            // 
            // Four3
            // 
            this.Four3.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.Four3.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.Four3.Font = new System.Drawing.Font("Stencil", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Four3.Location = new System.Drawing.Point(243, 442);
            this.Four3.Multiline = true;
            this.Four3.Name = "Four3";
            this.Four3.Size = new System.Drawing.Size(50, 49);
            this.Four3.TabIndex = 39;
            this.Four3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Four3.TextChanged += new System.EventHandler(this.Four3_TextChanged);
            // 
            // Four2
            // 
            this.Four2.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.Four2.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.Four2.Font = new System.Drawing.Font("Stencil", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Four2.Location = new System.Drawing.Point(178, 442);
            this.Four2.Multiline = true;
            this.Four2.Name = "Four2";
            this.Four2.Size = new System.Drawing.Size(50, 49);
            this.Four2.TabIndex = 38;
            this.Four2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Four2.TextChanged += new System.EventHandler(this.Four2_TextChanged);
            // 
            // Four1
            // 
            this.Four1.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.Four1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.Four1.Font = new System.Drawing.Font("Stencil", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Four1.Location = new System.Drawing.Point(113, 442);
            this.Four1.Multiline = true;
            this.Four1.Name = "Four1";
            this.Four1.Size = new System.Drawing.Size(50, 49);
            this.Four1.TabIndex = 37;
            this.Four1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Four1.TextChanged += new System.EventHandler(this.Four1_TextChanged);
            // 
            // Four0
            // 
            this.Four0.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.Four0.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.Four0.Font = new System.Drawing.Font("Stencil", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Four0.Location = new System.Drawing.Point(48, 442);
            this.Four0.Multiline = true;
            this.Four0.Name = "Four0";
            this.Four0.Size = new System.Drawing.Size(50, 49);
            this.Four0.TabIndex = 36;
            this.Four0.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Four0.TextChanged += new System.EventHandler(this.Four0_TextChanged);
            // 
            // Five8
            // 
            this.Five8.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.Five8.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.Five8.Font = new System.Drawing.Font("Stencil", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Five8.Location = new System.Drawing.Point(572, 514);
            this.Five8.Multiline = true;
            this.Five8.Name = "Five8";
            this.Five8.Size = new System.Drawing.Size(50, 49);
            this.Five8.TabIndex = 53;
            this.Five8.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Five8.TextChanged += new System.EventHandler(this.Five8_TextChanged);
            // 
            // Five7
            // 
            this.Five7.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.Five7.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.Five7.Font = new System.Drawing.Font("Stencil", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Five7.Location = new System.Drawing.Point(506, 514);
            this.Five7.Multiline = true;
            this.Five7.Name = "Five7";
            this.Five7.Size = new System.Drawing.Size(50, 49);
            this.Five7.TabIndex = 52;
            this.Five7.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Five7.TextChanged += new System.EventHandler(this.Five7_TextChanged);
            // 
            // Five6
            // 
            this.Five6.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.Five6.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.Five6.Font = new System.Drawing.Font("Stencil", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Five6.Location = new System.Drawing.Point(441, 514);
            this.Five6.Multiline = true;
            this.Five6.Name = "Five6";
            this.Five6.Size = new System.Drawing.Size(50, 49);
            this.Five6.TabIndex = 51;
            this.Five6.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Five6.TextChanged += new System.EventHandler(this.Five6_TextChanged);
            // 
            // Five5
            // 
            this.Five5.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.Five5.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.Five5.Font = new System.Drawing.Font("Stencil", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Five5.Location = new System.Drawing.Point(374, 514);
            this.Five5.Multiline = true;
            this.Five5.Name = "Five5";
            this.Five5.Size = new System.Drawing.Size(50, 49);
            this.Five5.TabIndex = 50;
            this.Five5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Five5.TextChanged += new System.EventHandler(this.Five5_TextChanged);
            // 
            // Five4
            // 
            this.Five4.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.Five4.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.Five4.Font = new System.Drawing.Font("Stencil", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Five4.Location = new System.Drawing.Point(309, 514);
            this.Five4.Multiline = true;
            this.Five4.Name = "Five4";
            this.Five4.Size = new System.Drawing.Size(50, 49);
            this.Five4.TabIndex = 49;
            this.Five4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Five4.TextChanged += new System.EventHandler(this.Five4_TextChanged);
            // 
            // Five3
            // 
            this.Five3.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.Five3.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.Five3.Font = new System.Drawing.Font("Stencil", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Five3.Location = new System.Drawing.Point(243, 514);
            this.Five3.Multiline = true;
            this.Five3.Name = "Five3";
            this.Five3.Size = new System.Drawing.Size(50, 49);
            this.Five3.TabIndex = 48;
            this.Five3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Five3.TextChanged += new System.EventHandler(this.Five3_TextChanged);
            // 
            // Five2
            // 
            this.Five2.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.Five2.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.Five2.Font = new System.Drawing.Font("Stencil", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Five2.Location = new System.Drawing.Point(178, 514);
            this.Five2.Multiline = true;
            this.Five2.Name = "Five2";
            this.Five2.Size = new System.Drawing.Size(50, 49);
            this.Five2.TabIndex = 47;
            this.Five2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Five2.TextChanged += new System.EventHandler(this.Five2_TextChanged);
            // 
            // Five1
            // 
            this.Five1.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.Five1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.Five1.Font = new System.Drawing.Font("Stencil", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Five1.Location = new System.Drawing.Point(113, 514);
            this.Five1.Multiline = true;
            this.Five1.Name = "Five1";
            this.Five1.Size = new System.Drawing.Size(50, 49);
            this.Five1.TabIndex = 46;
            this.Five1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Five1.TextChanged += new System.EventHandler(this.Five1_TextChanged);
            // 
            // Five0
            // 
            this.Five0.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.Five0.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.Five0.Font = new System.Drawing.Font("Stencil", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Five0.Location = new System.Drawing.Point(48, 514);
            this.Five0.Multiline = true;
            this.Five0.Name = "Five0";
            this.Five0.Size = new System.Drawing.Size(50, 49);
            this.Five0.TabIndex = 45;
            this.Five0.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Five0.TextChanged += new System.EventHandler(this.Five0_TextChanged);
            // 
            // Six8
            // 
            this.Six8.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.Six8.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.Six8.Font = new System.Drawing.Font("Stencil", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Six8.Location = new System.Drawing.Point(572, 586);
            this.Six8.Multiline = true;
            this.Six8.Name = "Six8";
            this.Six8.Size = new System.Drawing.Size(50, 49);
            this.Six8.TabIndex = 62;
            this.Six8.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Six8.TextChanged += new System.EventHandler(this.Six8_TextChanged);
            // 
            // Six7
            // 
            this.Six7.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.Six7.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.Six7.Font = new System.Drawing.Font("Stencil", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Six7.Location = new System.Drawing.Point(506, 586);
            this.Six7.Multiline = true;
            this.Six7.Name = "Six7";
            this.Six7.Size = new System.Drawing.Size(50, 49);
            this.Six7.TabIndex = 61;
            this.Six7.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Six7.TextChanged += new System.EventHandler(this.Six7_TextChanged);
            // 
            // Six6
            // 
            this.Six6.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.Six6.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.Six6.Font = new System.Drawing.Font("Stencil", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Six6.Location = new System.Drawing.Point(441, 586);
            this.Six6.Multiline = true;
            this.Six6.Name = "Six6";
            this.Six6.Size = new System.Drawing.Size(50, 49);
            this.Six6.TabIndex = 60;
            this.Six6.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Six6.TextChanged += new System.EventHandler(this.Six6_TextChanged);
            // 
            // Six5
            // 
            this.Six5.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.Six5.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.Six5.Font = new System.Drawing.Font("Stencil", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Six5.Location = new System.Drawing.Point(374, 586);
            this.Six5.Multiline = true;
            this.Six5.Name = "Six5";
            this.Six5.Size = new System.Drawing.Size(50, 49);
            this.Six5.TabIndex = 59;
            this.Six5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Six5.TextChanged += new System.EventHandler(this.Six5_TextChanged);
            // 
            // Six4
            // 
            this.Six4.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.Six4.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.Six4.Font = new System.Drawing.Font("Stencil", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Six4.Location = new System.Drawing.Point(309, 586);
            this.Six4.Multiline = true;
            this.Six4.Name = "Six4";
            this.Six4.Size = new System.Drawing.Size(50, 49);
            this.Six4.TabIndex = 58;
            this.Six4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Six4.TextChanged += new System.EventHandler(this.Six4_TextChanged);
            // 
            // Six3
            // 
            this.Six3.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.Six3.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.Six3.Font = new System.Drawing.Font("Stencil", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Six3.Location = new System.Drawing.Point(243, 586);
            this.Six3.Multiline = true;
            this.Six3.Name = "Six3";
            this.Six3.Size = new System.Drawing.Size(50, 49);
            this.Six3.TabIndex = 57;
            this.Six3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Six3.TextChanged += new System.EventHandler(this.Six3_TextChanged);
            // 
            // Six2
            // 
            this.Six2.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.Six2.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.Six2.Font = new System.Drawing.Font("Stencil", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Six2.Location = new System.Drawing.Point(178, 586);
            this.Six2.Multiline = true;
            this.Six2.Name = "Six2";
            this.Six2.Size = new System.Drawing.Size(50, 49);
            this.Six2.TabIndex = 56;
            this.Six2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Six2.TextChanged += new System.EventHandler(this.Six2_TextChanged);
            // 
            // Six1
            // 
            this.Six1.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.Six1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.Six1.Font = new System.Drawing.Font("Stencil", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Six1.Location = new System.Drawing.Point(113, 586);
            this.Six1.Multiline = true;
            this.Six1.Name = "Six1";
            this.Six1.Size = new System.Drawing.Size(50, 49);
            this.Six1.TabIndex = 55;
            this.Six1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Six1.TextChanged += new System.EventHandler(this.Six1_TextChanged);
            // 
            // Six0
            // 
            this.Six0.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.Six0.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.Six0.Font = new System.Drawing.Font("Stencil", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Six0.Location = new System.Drawing.Point(48, 586);
            this.Six0.Multiline = true;
            this.Six0.Name = "Six0";
            this.Six0.Size = new System.Drawing.Size(50, 49);
            this.Six0.TabIndex = 54;
            this.Six0.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Six0.TextChanged += new System.EventHandler(this.Six0_TextChanged);
            // 
            // Seven8
            // 
            this.Seven8.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.Seven8.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.Seven8.Font = new System.Drawing.Font("Stencil", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Seven8.Location = new System.Drawing.Point(572, 656);
            this.Seven8.Multiline = true;
            this.Seven8.Name = "Seven8";
            this.Seven8.Size = new System.Drawing.Size(50, 49);
            this.Seven8.TabIndex = 71;
            this.Seven8.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Seven8.TextChanged += new System.EventHandler(this.Seven8_TextChanged);
            // 
            // Seven7
            // 
            this.Seven7.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.Seven7.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.Seven7.Font = new System.Drawing.Font("Stencil", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Seven7.Location = new System.Drawing.Point(506, 656);
            this.Seven7.Multiline = true;
            this.Seven7.Name = "Seven7";
            this.Seven7.Size = new System.Drawing.Size(50, 49);
            this.Seven7.TabIndex = 70;
            this.Seven7.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Seven7.TextChanged += new System.EventHandler(this.Seven7_TextChanged);
            // 
            // Seven6
            // 
            this.Seven6.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.Seven6.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.Seven6.Font = new System.Drawing.Font("Stencil", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Seven6.Location = new System.Drawing.Point(441, 656);
            this.Seven6.Multiline = true;
            this.Seven6.Name = "Seven6";
            this.Seven6.Size = new System.Drawing.Size(50, 49);
            this.Seven6.TabIndex = 69;
            this.Seven6.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Seven6.TextChanged += new System.EventHandler(this.Seven6_TextChanged);
            // 
            // Seven5
            // 
            this.Seven5.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.Seven5.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.Seven5.Font = new System.Drawing.Font("Stencil", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Seven5.Location = new System.Drawing.Point(374, 656);
            this.Seven5.Multiline = true;
            this.Seven5.Name = "Seven5";
            this.Seven5.Size = new System.Drawing.Size(50, 49);
            this.Seven5.TabIndex = 68;
            this.Seven5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Seven5.TextChanged += new System.EventHandler(this.Seven5_TextChanged);
            // 
            // Seven4
            // 
            this.Seven4.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.Seven4.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.Seven4.Font = new System.Drawing.Font("Stencil", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Seven4.Location = new System.Drawing.Point(309, 656);
            this.Seven4.Multiline = true;
            this.Seven4.Name = "Seven4";
            this.Seven4.Size = new System.Drawing.Size(50, 49);
            this.Seven4.TabIndex = 67;
            this.Seven4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Seven4.TextChanged += new System.EventHandler(this.Seven4_TextChanged);
            // 
            // Seven3
            // 
            this.Seven3.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.Seven3.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.Seven3.Font = new System.Drawing.Font("Stencil", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Seven3.Location = new System.Drawing.Point(243, 656);
            this.Seven3.Multiline = true;
            this.Seven3.Name = "Seven3";
            this.Seven3.Size = new System.Drawing.Size(50, 49);
            this.Seven3.TabIndex = 66;
            this.Seven3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Seven3.TextChanged += new System.EventHandler(this.Seven3_TextChanged);
            // 
            // Seven2
            // 
            this.Seven2.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.Seven2.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.Seven2.Font = new System.Drawing.Font("Stencil", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Seven2.Location = new System.Drawing.Point(178, 656);
            this.Seven2.Multiline = true;
            this.Seven2.Name = "Seven2";
            this.Seven2.Size = new System.Drawing.Size(50, 49);
            this.Seven2.TabIndex = 65;
            this.Seven2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Seven2.TextChanged += new System.EventHandler(this.Seven2_TextChanged);
            // 
            // Seven1
            // 
            this.Seven1.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.Seven1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.Seven1.Font = new System.Drawing.Font("Stencil", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Seven1.Location = new System.Drawing.Point(113, 656);
            this.Seven1.Multiline = true;
            this.Seven1.Name = "Seven1";
            this.Seven1.Size = new System.Drawing.Size(50, 49);
            this.Seven1.TabIndex = 64;
            this.Seven1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Seven1.TextChanged += new System.EventHandler(this.Seven1_TextChanged);
            // 
            // Seven0
            // 
            this.Seven0.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.Seven0.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.Seven0.Font = new System.Drawing.Font("Stencil", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Seven0.Location = new System.Drawing.Point(48, 656);
            this.Seven0.Multiline = true;
            this.Seven0.Name = "Seven0";
            this.Seven0.Size = new System.Drawing.Size(50, 49);
            this.Seven0.TabIndex = 63;
            this.Seven0.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Seven0.TextChanged += new System.EventHandler(this.Seven0_TextChanged);
            // 
            // Eight8
            // 
            this.Eight8.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.Eight8.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.Eight8.Font = new System.Drawing.Font("Stencil", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Eight8.Location = new System.Drawing.Point(572, 727);
            this.Eight8.Multiline = true;
            this.Eight8.Name = "Eight8";
            this.Eight8.Size = new System.Drawing.Size(50, 49);
            this.Eight8.TabIndex = 80;
            this.Eight8.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Eight8.TextChanged += new System.EventHandler(this.Eight8_TextChanged);
            // 
            // Eight7
            // 
            this.Eight7.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.Eight7.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.Eight7.Font = new System.Drawing.Font("Stencil", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Eight7.Location = new System.Drawing.Point(506, 727);
            this.Eight7.Multiline = true;
            this.Eight7.Name = "Eight7";
            this.Eight7.Size = new System.Drawing.Size(50, 49);
            this.Eight7.TabIndex = 79;
            this.Eight7.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Eight7.TextChanged += new System.EventHandler(this.Eight7_TextChanged);
            // 
            // Eight6
            // 
            this.Eight6.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.Eight6.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.Eight6.Font = new System.Drawing.Font("Stencil", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Eight6.Location = new System.Drawing.Point(441, 727);
            this.Eight6.Multiline = true;
            this.Eight6.Name = "Eight6";
            this.Eight6.Size = new System.Drawing.Size(50, 49);
            this.Eight6.TabIndex = 78;
            this.Eight6.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Eight6.TextChanged += new System.EventHandler(this.Eight6_TextChanged);
            // 
            // Eight5
            // 
            this.Eight5.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.Eight5.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.Eight5.Font = new System.Drawing.Font("Stencil", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Eight5.Location = new System.Drawing.Point(374, 727);
            this.Eight5.Multiline = true;
            this.Eight5.Name = "Eight5";
            this.Eight5.Size = new System.Drawing.Size(50, 49);
            this.Eight5.TabIndex = 77;
            this.Eight5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Eight5.TextChanged += new System.EventHandler(this.Eight5_TextChanged);
            // 
            // Eight4
            // 
            this.Eight4.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.Eight4.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.Eight4.Font = new System.Drawing.Font("Stencil", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Eight4.Location = new System.Drawing.Point(309, 727);
            this.Eight4.Multiline = true;
            this.Eight4.Name = "Eight4";
            this.Eight4.Size = new System.Drawing.Size(50, 49);
            this.Eight4.TabIndex = 76;
            this.Eight4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Eight4.TextChanged += new System.EventHandler(this.Eight4_TextChanged);
            // 
            // Eight3
            // 
            this.Eight3.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.Eight3.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.Eight3.Font = new System.Drawing.Font("Stencil", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Eight3.Location = new System.Drawing.Point(243, 727);
            this.Eight3.Multiline = true;
            this.Eight3.Name = "Eight3";
            this.Eight3.Size = new System.Drawing.Size(50, 49);
            this.Eight3.TabIndex = 75;
            this.Eight3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Eight3.TextChanged += new System.EventHandler(this.Eight3_TextChanged);
            // 
            // Eight2
            // 
            this.Eight2.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.Eight2.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.Eight2.Font = new System.Drawing.Font("Stencil", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Eight2.Location = new System.Drawing.Point(178, 727);
            this.Eight2.Multiline = true;
            this.Eight2.Name = "Eight2";
            this.Eight2.Size = new System.Drawing.Size(50, 49);
            this.Eight2.TabIndex = 74;
            this.Eight2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Eight2.TextChanged += new System.EventHandler(this.Eight2_TextChanged);
            // 
            // Eight1
            // 
            this.Eight1.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.Eight1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.Eight1.Font = new System.Drawing.Font("Stencil", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Eight1.Location = new System.Drawing.Point(113, 727);
            this.Eight1.Multiline = true;
            this.Eight1.Name = "Eight1";
            this.Eight1.Size = new System.Drawing.Size(50, 49);
            this.Eight1.TabIndex = 73;
            this.Eight1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Eight1.TextChanged += new System.EventHandler(this.Eight1_TextChanged);
            // 
            // Eight0
            // 
            this.Eight0.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.Eight0.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.Eight0.Font = new System.Drawing.Font("Stencil", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Eight0.Location = new System.Drawing.Point(48, 727);
            this.Eight0.Multiline = true;
            this.Eight0.Name = "Eight0";
            this.Eight0.Size = new System.Drawing.Size(50, 49);
            this.Eight0.TabIndex = 72;
            this.Eight0.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Eight0.TextChanged += new System.EventHandler(this.Eight0_TextChanged);
            // 
            // textBox82
            // 
            this.textBox82.BackColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.textBox82.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox82.Font = new System.Drawing.Font("Stencil", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox82.Location = new System.Drawing.Point(95, 157);
            this.textBox82.Multiline = true;
            this.textBox82.Name = "textBox82";
            this.textBox82.Size = new System.Drawing.Size(24, 619);
            this.textBox82.TabIndex = 81;
            this.textBox82.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox83
            // 
            this.textBox83.BackColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.textBox83.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox83.Font = new System.Drawing.Font("Stencil", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox83.Location = new System.Drawing.Point(159, 157);
            this.textBox83.Multiline = true;
            this.textBox83.Name = "textBox83";
            this.textBox83.Size = new System.Drawing.Size(24, 619);
            this.textBox83.TabIndex = 82;
            this.textBox83.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox84
            // 
            this.textBox84.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.textBox84.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox84.Font = new System.Drawing.Font("Stencil", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox84.Location = new System.Drawing.Point(225, 157);
            this.textBox84.Multiline = true;
            this.textBox84.Name = "textBox84";
            this.textBox84.Size = new System.Drawing.Size(24, 619);
            this.textBox84.TabIndex = 83;
            this.textBox84.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox85
            // 
            this.textBox85.BackColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.textBox85.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox85.Font = new System.Drawing.Font("Stencil", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox85.Location = new System.Drawing.Point(288, 157);
            this.textBox85.Multiline = true;
            this.textBox85.Name = "textBox85";
            this.textBox85.Size = new System.Drawing.Size(24, 619);
            this.textBox85.TabIndex = 84;
            this.textBox85.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox86
            // 
            this.textBox86.BackColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.textBox86.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox86.Font = new System.Drawing.Font("Stencil", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox86.Location = new System.Drawing.Point(355, 157);
            this.textBox86.Multiline = true;
            this.textBox86.Name = "textBox86";
            this.textBox86.Size = new System.Drawing.Size(24, 619);
            this.textBox86.TabIndex = 85;
            this.textBox86.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox87
            // 
            this.textBox87.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.textBox87.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox87.Font = new System.Drawing.Font("Stencil", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox87.Location = new System.Drawing.Point(420, 157);
            this.textBox87.Multiline = true;
            this.textBox87.Name = "textBox87";
            this.textBox87.Size = new System.Drawing.Size(24, 619);
            this.textBox87.TabIndex = 86;
            this.textBox87.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox88
            // 
            this.textBox88.BackColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.textBox88.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox88.Font = new System.Drawing.Font("Stencil", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox88.Location = new System.Drawing.Point(488, 157);
            this.textBox88.Multiline = true;
            this.textBox88.Name = "textBox88";
            this.textBox88.Size = new System.Drawing.Size(24, 619);
            this.textBox88.TabIndex = 87;
            this.textBox88.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox89
            // 
            this.textBox89.BackColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.textBox89.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox89.Font = new System.Drawing.Font("Stencil", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox89.Location = new System.Drawing.Point(552, 157);
            this.textBox89.Multiline = true;
            this.textBox89.Name = "textBox89";
            this.textBox89.Size = new System.Drawing.Size(24, 619);
            this.textBox89.TabIndex = 88;
            this.textBox89.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox90
            // 
            this.textBox90.BackColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.textBox90.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox90.Font = new System.Drawing.Font("Stencil", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox90.Location = new System.Drawing.Point(48, 198);
            this.textBox90.Multiline = true;
            this.textBox90.Name = "textBox90";
            this.textBox90.Size = new System.Drawing.Size(574, 30);
            this.textBox90.TabIndex = 89;
            this.textBox90.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox91
            // 
            this.textBox91.BackColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.textBox91.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox91.Font = new System.Drawing.Font("Stencil", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox91.Location = new System.Drawing.Point(48, 272);
            this.textBox91.Multiline = true;
            this.textBox91.Name = "textBox91";
            this.textBox91.Size = new System.Drawing.Size(574, 30);
            this.textBox91.TabIndex = 90;
            this.textBox91.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox92
            // 
            this.textBox92.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.textBox92.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox92.Font = new System.Drawing.Font("Stencil", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox92.Location = new System.Drawing.Point(48, 344);
            this.textBox92.Multiline = true;
            this.textBox92.Name = "textBox92";
            this.textBox92.Size = new System.Drawing.Size(574, 30);
            this.textBox92.TabIndex = 91;
            this.textBox92.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox93
            // 
            this.textBox93.BackColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.textBox93.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox93.Font = new System.Drawing.Font("Stencil", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox93.Location = new System.Drawing.Point(48, 415);
            this.textBox93.Multiline = true;
            this.textBox93.Name = "textBox93";
            this.textBox93.Size = new System.Drawing.Size(574, 30);
            this.textBox93.TabIndex = 92;
            this.textBox93.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox94
            // 
            this.textBox94.BackColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.textBox94.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox94.Font = new System.Drawing.Font("Stencil", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox94.Location = new System.Drawing.Point(48, 487);
            this.textBox94.Multiline = true;
            this.textBox94.Name = "textBox94";
            this.textBox94.Size = new System.Drawing.Size(574, 30);
            this.textBox94.TabIndex = 93;
            this.textBox94.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox95
            // 
            this.textBox95.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.textBox95.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox95.Font = new System.Drawing.Font("Stencil", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox95.Location = new System.Drawing.Point(48, 559);
            this.textBox95.Multiline = true;
            this.textBox95.Name = "textBox95";
            this.textBox95.Size = new System.Drawing.Size(574, 30);
            this.textBox95.TabIndex = 94;
            this.textBox95.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox96
            // 
            this.textBox96.BackColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.textBox96.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox96.Font = new System.Drawing.Font("Stencil", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox96.Location = new System.Drawing.Point(48, 630);
            this.textBox96.Multiline = true;
            this.textBox96.Name = "textBox96";
            this.textBox96.Size = new System.Drawing.Size(574, 30);
            this.textBox96.TabIndex = 95;
            this.textBox96.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox97
            // 
            this.textBox97.BackColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.textBox97.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox97.Font = new System.Drawing.Font("Stencil", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox97.Location = new System.Drawing.Point(48, 701);
            this.textBox97.Multiline = true;
            this.textBox97.Name = "textBox97";
            this.textBox97.Size = new System.Drawing.Size(574, 30);
            this.textBox97.TabIndex = 96;
            this.textBox97.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label1
            // 
            this.label1.Location = new System.Drawing.Point(0, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(100, 23);
            this.label1.TabIndex = 0;
            // 
            // Sudoku1
            // 
            this.Sudoku1.AutoSize = true;
            this.Sudoku1.BackColor = System.Drawing.SystemColors.Control;
            this.Sudoku1.Font = new System.Drawing.Font("Microsoft YaHei", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Sudoku1.ForeColor = System.Drawing.SystemColors.WindowText;
            this.Sudoku1.Location = new System.Drawing.Point(44, 23);
            this.Sudoku1.Name = "Sudoku1";
            this.Sudoku1.Size = new System.Drawing.Size(315, 96);
            this.Sudoku1.TabIndex = 97;
            this.Sudoku1.Text = "Sudoku";
            this.Sudoku1.Click += new System.EventHandler(this.Sudoku1_Click);
            // 
            // Reset_Button
            // 
            this.Reset_Button.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.Reset_Button.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Reset_Button.Font = new System.Drawing.Font("Microsoft YaHei", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Reset_Button.Location = new System.Drawing.Point(460, 91);
            this.Reset_Button.Name = "Reset_Button";
            this.Reset_Button.Size = new System.Drawing.Size(116, 48);
            this.Reset_Button.TabIndex = 98;
            this.Reset_Button.Text = "Reset";
            this.Reset_Button.UseVisualStyleBackColor = false;
            this.Reset_Button.Click += new System.EventHandler(this.Reset_Button_Click);
            // 
            // Check_Button
            // 
            this.Check_Button.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.Check_Button.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Check_Button.Font = new System.Drawing.Font("Microsoft YaHei", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Check_Button.Location = new System.Drawing.Point(460, 23);
            this.Check_Button.Name = "Check_Button";
            this.Check_Button.Size = new System.Drawing.Size(116, 53);
            this.Check_Button.TabIndex = 99;
            this.Check_Button.Text = "Check";
            this.Check_Button.UseVisualStyleBackColor = false;
            this.Check_Button.Click += new System.EventHandler(this.Check_Button_Click);
            // 
            // Sudoku
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(677, 815);
            this.Controls.Add(this.Check_Button);
            this.Controls.Add(this.Reset_Button);
            this.Controls.Add(this.Sudoku1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textBox95);
            this.Controls.Add(this.textBox87);
            this.Controls.Add(this.textBox84);
            this.Controls.Add(this.textBox97);
            this.Controls.Add(this.textBox96);
            this.Controls.Add(this.textBox94);
            this.Controls.Add(this.textBox93);
            this.Controls.Add(this.textBox92);
            this.Controls.Add(this.textBox91);
            this.Controls.Add(this.textBox90);
            this.Controls.Add(this.textBox89);
            this.Controls.Add(this.textBox88);
            this.Controls.Add(this.textBox86);
            this.Controls.Add(this.textBox85);
            this.Controls.Add(this.textBox83);
            this.Controls.Add(this.textBox82);
            this.Controls.Add(this.Eight8);
            this.Controls.Add(this.Eight7);
            this.Controls.Add(this.Eight6);
            this.Controls.Add(this.Eight5);
            this.Controls.Add(this.Eight4);
            this.Controls.Add(this.Eight3);
            this.Controls.Add(this.Eight2);
            this.Controls.Add(this.Eight1);
            this.Controls.Add(this.Eight0);
            this.Controls.Add(this.Seven8);
            this.Controls.Add(this.Seven7);
            this.Controls.Add(this.Seven6);
            this.Controls.Add(this.Seven5);
            this.Controls.Add(this.Seven4);
            this.Controls.Add(this.Seven3);
            this.Controls.Add(this.Seven2);
            this.Controls.Add(this.Seven1);
            this.Controls.Add(this.Seven0);
            this.Controls.Add(this.Six8);
            this.Controls.Add(this.Six7);
            this.Controls.Add(this.Six6);
            this.Controls.Add(this.Six5);
            this.Controls.Add(this.Six4);
            this.Controls.Add(this.Six3);
            this.Controls.Add(this.Six2);
            this.Controls.Add(this.Six1);
            this.Controls.Add(this.Six0);
            this.Controls.Add(this.Five8);
            this.Controls.Add(this.Five7);
            this.Controls.Add(this.Five6);
            this.Controls.Add(this.Five5);
            this.Controls.Add(this.Five4);
            this.Controls.Add(this.Five3);
            this.Controls.Add(this.Five2);
            this.Controls.Add(this.Five1);
            this.Controls.Add(this.Five0);
            this.Controls.Add(this.Four8);
            this.Controls.Add(this.Four7);
            this.Controls.Add(this.Four6);
            this.Controls.Add(this.Four5);
            this.Controls.Add(this.Four4);
            this.Controls.Add(this.Four3);
            this.Controls.Add(this.Four2);
            this.Controls.Add(this.Four1);
            this.Controls.Add(this.Four0);
            this.Controls.Add(this.Three8);
            this.Controls.Add(this.Three7);
            this.Controls.Add(this.Three6);
            this.Controls.Add(this.Three5);
            this.Controls.Add(this.Three4);
            this.Controls.Add(this.Three3);
            this.Controls.Add(this.Three2);
            this.Controls.Add(this.Three1);
            this.Controls.Add(this.Three0);
            this.Controls.Add(this.Two8);
            this.Controls.Add(this.Two7);
            this.Controls.Add(this.Two6);
            this.Controls.Add(this.Two5);
            this.Controls.Add(this.Two4);
            this.Controls.Add(this.Two3);
            this.Controls.Add(this.Two2);
            this.Controls.Add(this.Two1);
            this.Controls.Add(this.Two0);
            this.Controls.Add(this.One8);
            this.Controls.Add(this.One7);
            this.Controls.Add(this.One6);
            this.Controls.Add(this.One5);
            this.Controls.Add(this.One4);
            this.Controls.Add(this.One3);
            this.Controls.Add(this.One2);
            this.Controls.Add(this.One1);
            this.Controls.Add(this.One0);
            this.Controls.Add(this.zero8);
            this.Controls.Add(this.zero7);
            this.Controls.Add(this.zero6);
            this.Controls.Add(this.Zero5);
            this.Controls.Add(this.Zero4);
            this.Controls.Add(this.Zero3);
            this.Controls.Add(this.Zero2);
            this.Controls.Add(this.Zero1);
            this.Controls.Add(this.Zero0);
            this.Name = "Sudoku";
            this.Text = "Sudoku";
            this.Load += new System.EventHandler(this.Sudoku_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox Zero0;
        private System.Windows.Forms.TextBox Zero1;
        private System.Windows.Forms.TextBox Zero3;
        private System.Windows.Forms.TextBox Zero2;
        private System.Windows.Forms.TextBox Zero5;
        private System.Windows.Forms.TextBox Zero4;
        private System.Windows.Forms.TextBox zero7;
        private System.Windows.Forms.TextBox zero6;
        private System.Windows.Forms.TextBox zero8;
        private System.Windows.Forms.TextBox One8;
        private System.Windows.Forms.TextBox One7;
        private System.Windows.Forms.TextBox One6;
        private System.Windows.Forms.TextBox One5;
        private System.Windows.Forms.TextBox One4;
        private System.Windows.Forms.TextBox One3;
        private System.Windows.Forms.TextBox One2;
        private System.Windows.Forms.TextBox One1;
        private System.Windows.Forms.TextBox One0;
        private System.Windows.Forms.TextBox Two8;
        private System.Windows.Forms.TextBox Two7;
        private System.Windows.Forms.TextBox Two6;
        private System.Windows.Forms.TextBox Two5;
        private System.Windows.Forms.TextBox Two4;
        private System.Windows.Forms.TextBox Two3;
        private System.Windows.Forms.TextBox Two2;
        private System.Windows.Forms.TextBox Two1;
        private System.Windows.Forms.TextBox Two0;
        private System.Windows.Forms.TextBox Three8;
        private System.Windows.Forms.TextBox Three7;
        private System.Windows.Forms.TextBox Three6;
        private System.Windows.Forms.TextBox Three5;
        private System.Windows.Forms.TextBox Three4;
        private System.Windows.Forms.TextBox Three3;
        private System.Windows.Forms.TextBox Three2;
        private System.Windows.Forms.TextBox Three1;
        private System.Windows.Forms.TextBox Three0;
        private System.Windows.Forms.TextBox Four8;
        private System.Windows.Forms.TextBox Four7;
        private System.Windows.Forms.TextBox Four6;
        private System.Windows.Forms.TextBox Four5;
        private System.Windows.Forms.TextBox Four4;
        private System.Windows.Forms.TextBox Four3;
        private System.Windows.Forms.TextBox Four2;
        private System.Windows.Forms.TextBox Four1;
        private System.Windows.Forms.TextBox Four0;
        private System.Windows.Forms.TextBox Five8;
        private System.Windows.Forms.TextBox Five7;
        private System.Windows.Forms.TextBox Five6;
        private System.Windows.Forms.TextBox Five5;
        private System.Windows.Forms.TextBox Five4;
        private System.Windows.Forms.TextBox Five3;
        private System.Windows.Forms.TextBox Five2;
        private System.Windows.Forms.TextBox Five1;
        private System.Windows.Forms.TextBox Five0;
        private System.Windows.Forms.TextBox Six8;
        private System.Windows.Forms.TextBox Six7;
        private System.Windows.Forms.TextBox Six6;
        private System.Windows.Forms.TextBox Six5;
        private System.Windows.Forms.TextBox Six4;
        private System.Windows.Forms.TextBox Six3;
        private System.Windows.Forms.TextBox Six2;
        private System.Windows.Forms.TextBox Six1;
        private System.Windows.Forms.TextBox Six0;
        private System.Windows.Forms.TextBox Seven8;
        private System.Windows.Forms.TextBox Seven7;
        private System.Windows.Forms.TextBox Seven6;
        private System.Windows.Forms.TextBox Seven5;
        private System.Windows.Forms.TextBox Seven4;
        private System.Windows.Forms.TextBox Seven3;
        private System.Windows.Forms.TextBox Seven2;
        private System.Windows.Forms.TextBox Seven1;
        private System.Windows.Forms.TextBox Seven0;
        private System.Windows.Forms.TextBox Eight8;
        private System.Windows.Forms.TextBox Eight7;
        private System.Windows.Forms.TextBox Eight6;
        private System.Windows.Forms.TextBox Eight5;
        private System.Windows.Forms.TextBox Eight4;
        private System.Windows.Forms.TextBox Eight3;
        private System.Windows.Forms.TextBox Eight2;
        private System.Windows.Forms.TextBox Eight1;
        private System.Windows.Forms.TextBox Eight0;
        private System.Windows.Forms.TextBox textBox82;
        private System.Windows.Forms.TextBox textBox83;
        private System.Windows.Forms.TextBox textBox84;
        private System.Windows.Forms.TextBox textBox85;
        private System.Windows.Forms.TextBox textBox86;
        private System.Windows.Forms.TextBox textBox87;
        private System.Windows.Forms.TextBox textBox88;
        private System.Windows.Forms.TextBox textBox89;
        private System.Windows.Forms.TextBox textBox90;
        private System.Windows.Forms.TextBox textBox91;
        private System.Windows.Forms.TextBox textBox92;
        private System.Windows.Forms.TextBox textBox93;
        private System.Windows.Forms.TextBox textBox94;
        private System.Windows.Forms.TextBox textBox95;
        private System.Windows.Forms.TextBox textBox96;
        private System.Windows.Forms.TextBox textBox97;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label Sudoku1;
        private System.Windows.Forms.Button Reset_Button;
        private System.Windows.Forms.Button Check_Button;
    }
}