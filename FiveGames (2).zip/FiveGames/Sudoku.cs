﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FiveGames
{
    public partial class Sudoku : Form
    {
        public Sudoku()
        {
            InitializeComponent();
        }

        private void Sudoku_Load(object sender, EventArgs e)
        {

        }

        private void Sudoku1_Click(object sender, EventArgs e)
        {

        }

        private void Zero0_TextChanged(object sender, EventArgs e)
        {

        }

        private void Zero1_TextChanged(object sender, EventArgs e)
        {

        }

        private void Zero2_TextChanged(object sender, EventArgs e)
        {

        }

        private void Zero3_TextChanged(object sender, EventArgs e)
        {

        }

        private void Zero4_TextChanged(object sender, EventArgs e)
        {

        }

        private void Zero5_TextChanged(object sender, EventArgs e)
        {

        }

        private void zero6_TextChanged(object sender, EventArgs e)
        {

        }

        private void zero7_TextChanged(object sender, EventArgs e)
        {

        }

        private void zero8_TextChanged(object sender, EventArgs e)
        {

        }

        private void One0_TextChanged(object sender, EventArgs e)
        {

        }

        private void One1_TextChanged(object sender, EventArgs e)
        {

        }

        private void One2_TextChanged(object sender, EventArgs e)
        {

        }

        private void One3_TextChanged(object sender, EventArgs e)
        {

        }

        private void One4_TextChanged(object sender, EventArgs e)
        {

        }

        private void One5_TextChanged(object sender, EventArgs e)
        {

        }

        private void One6_TextChanged(object sender, EventArgs e)
        {

        }

        private void One7_TextChanged(object sender, EventArgs e)
        {

        }

        private void One8_TextChanged(object sender, EventArgs e)
        {

        }

        private void Two0_TextChanged(object sender, EventArgs e)
        {

        }

        private void Two1_TextChanged(object sender, EventArgs e)
        {

        }

        private void Two2_TextChanged(object sender, EventArgs e)
        {

        }

        private void Two3_TextChanged(object sender, EventArgs e)
        {

        }

        private void Two4_TextChanged(object sender, EventArgs e)
        {

        }

        private void Two5_TextChanged(object sender, EventArgs e)
        {

        }

        private void Two6_TextChanged(object sender, EventArgs e)
        {

        }

        private void Two7_TextChanged(object sender, EventArgs e)
        {

        }

        private void Two8_TextChanged(object sender, EventArgs e)
        {

        }

        private void Three0_TextChanged(object sender, EventArgs e)
        {

        }

        private void Three1_TextChanged(object sender, EventArgs e)
        {

        }

        private void Three2_TextChanged(object sender, EventArgs e)
        {

        }

        private void Three3_TextChanged(object sender, EventArgs e)
        {

        }

        private void Three4_TextChanged(object sender, EventArgs e)
        {

        }

        private void Three5_TextChanged(object sender, EventArgs e)
        {

        }

        private void Three6_TextChanged(object sender, EventArgs e)
        {

        }

        private void Three7_TextChanged(object sender, EventArgs e)
        {

        }

        private void Three8_TextChanged(object sender, EventArgs e)
        {

        }

        private void Four0_TextChanged(object sender, EventArgs e)
        {

        }

        private void Four1_TextChanged(object sender, EventArgs e)
        {

        }

        private void Four2_TextChanged(object sender, EventArgs e)
        {

        }

        private void Four3_TextChanged(object sender, EventArgs e)
        {

        }

        private void Four4_TextChanged(object sender, EventArgs e)
        {

        }

        private void Four5_TextChanged(object sender, EventArgs e)
        {

        }

        private void Four6_TextChanged(object sender, EventArgs e)
        {

        }

        private void Four7_TextChanged(object sender, EventArgs e)
        {

        }

        private void Four8_TextChanged(object sender, EventArgs e)
        {

        }

        private void Five0_TextChanged(object sender, EventArgs e)
        {

        }

        private void Five1_TextChanged(object sender, EventArgs e)
        {

        }

        private void Five2_TextChanged(object sender, EventArgs e)
        {

        }

        private void Five3_TextChanged(object sender, EventArgs e)
        {

        }

        private void Five4_TextChanged(object sender, EventArgs e)
        {

        }

        private void Five5_TextChanged(object sender, EventArgs e)
        {

        }

        private void Five6_TextChanged(object sender, EventArgs e)
        {

        }

        private void Five7_TextChanged(object sender, EventArgs e)
        {

        }

        private void Five8_TextChanged(object sender, EventArgs e)
        {

        }

        private void Six0_TextChanged(object sender, EventArgs e)
        {

        }

        private void Six1_TextChanged(object sender, EventArgs e)
        {

        }

        private void Six2_TextChanged(object sender, EventArgs e)
        {

        }

        private void Six3_TextChanged(object sender, EventArgs e)
        {

        }

        private void Six4_TextChanged(object sender, EventArgs e)
        {

        }

        private void Six5_TextChanged(object sender, EventArgs e)
        {

        }

        private void Six6_TextChanged(object sender, EventArgs e)
        {

        }

        private void Six7_TextChanged(object sender, EventArgs e)
        {

        }

        private void Six8_TextChanged(object sender, EventArgs e)
        {

        }

        private void Seven0_TextChanged(object sender, EventArgs e)
        {

        }

        private void Seven1_TextChanged(object sender, EventArgs e)
        {

        }

        private void Seven2_TextChanged(object sender, EventArgs e)
        {

        }

        private void Seven3_TextChanged(object sender, EventArgs e)
        {

        }

        private void Seven4_TextChanged(object sender, EventArgs e)
        {

        }

        private void Seven5_TextChanged(object sender, EventArgs e)
        {

        }

        private void Seven6_TextChanged(object sender, EventArgs e)
        {

        }

        private void Seven7_TextChanged(object sender, EventArgs e)
        {

        }

        private void Seven8_TextChanged(object sender, EventArgs e)
        {

        }

        private void Eight0_TextChanged(object sender, EventArgs e)
        {

        }

        private void Eight1_TextChanged(object sender, EventArgs e)
        {

        }

        private void Eight2_TextChanged(object sender, EventArgs e)
        {

        }

        private void Eight3_TextChanged(object sender, EventArgs e)
        {

        }

        private void Eight4_TextChanged(object sender, EventArgs e)
        {

        }

        private void Eight5_TextChanged(object sender, EventArgs e)
        {

        }

        private void Eight6_TextChanged(object sender, EventArgs e)
        {

        }

        private void Eight7_TextChanged(object sender, EventArgs e)
        {

        }

        private void Eight8_TextChanged(object sender, EventArgs e)
        {

        }

        private void Check_Button_Click(object sender, EventArgs e)
        {

        }

        private void Reset_Button_Click(object sender, EventArgs e)
        {

        }
    }
}
